#ifndef PART2_H
#define PART2_H

#define NUM_THREADS (6)

#include <pthread.h>

void *create_oxygen(void *ptr);
void *create_nitrogen(void *ptr);
void *create_n2(void *ptr);
void *create_o2(void *ptr);
void *create_no2(void *ptr);
void *create_o3(void *ptr);
void create_threads(pthread_t ***thread_arr_ptr, size_t oxygen_count, size_t nitrogen_count);

#endif // PART2_H
