#include "part1.h"

#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// The producers add the characters in g_prod_str to the g_buffer, in order.

char *g_prod_str = "The greatest teacher, failure is.";

bounded_buffer g_buffer = { 0 };

// This mutex must be held whenever you use the g_buffer.

pthread_mutex_t g_buffer_mutex = { 0 };


// g_empty_sem is the number of characters in the g_buffer,
// that need to be emptied.
// Producers should signal g_empty_sem and consumers should wait on it.

sem_t g_empty_sem = { 0 };

// g_full_sem is the opposite of g_empty_sem. It is the number of
// unfilled slots in the g_buffer that need to be filled. Consumers
// should signal it, and producers should wait on it.

sem_t g_full_sem = { 0 };

/*
 * Produce the characters (that is, add them to the g_buffer) from g_prod_str,
 *  in order. Signal consumers appropriately after each character.
 * Receive an ID via an (int *).
 */

void *producer(void *ptr) {
  int thread_id = *((int *) ptr);
  free(ptr);
  ptr = NULL;

  printf("Producer %d starting\n", thread_id);
  fflush(NULL);

  for (size_t i = 0; i < strlen(g_prod_str); i++) {
    // Add your code to wait on the semaphore and obtain the lock,
    // then add g_prod_str[i] to the g_buffer.

    // wait for there to be an empty space

    sem_wait(&g_full_sem);

    // obtain lock

    pthread_mutex_lock(&g_buffer_mutex);

    // add to buffer

    g_buffer.queue[g_buffer.tail] = g_prod_str[i];
    g_buffer.tail = (g_buffer.tail + 1) % BUF_SIZE;
    printf("Thread %d produced %c\n", thread_id, g_prod_str[i]);

    // unlock

    pthread_mutex_unlock(&g_buffer_mutex);

    // signal there's something to empty

    sem_post(&g_empty_sem);
  }

  pthread_exit(0);
} /* producer() */

/*
 * Consume characters from the g_buffer. Stop after consuming the length of
 * g_prod_str, meaning that if an equal number of consumers and producers are
 * started, they will all exit. Signal producers appropriately of new free
 * space in the g_buffer. Receive an ID as an argument via an (int *).
 */

void *consumer(void *ptr) {
  int thread_id = *((int *) ptr);
  free(ptr);
  ptr = NULL;

  printf("Consumer %d starting\n", thread_id);
  fflush(NULL);

  for (size_t i = 0; i < strlen(g_prod_str); i++) {
    // Add your code to wait on the semaphore and obtain the lock,
    // then consume one character from the g_buffer, replacing
    // the following line.

    // char c = g_prod_str[...];

    // wait for there to be something to empty

    sem_wait(&g_empty_sem);

    // obtain lock

    pthread_mutex_lock(&g_buffer_mutex);

    // grab value from buffer

    int val = g_buffer.queue[g_buffer.head];
    g_buffer.head = (g_buffer.head + 1) % BUF_SIZE;
    printf("Thread %d consumed %c\n", thread_id, val);

    // unlock

    pthread_mutex_unlock(&g_buffer_mutex);

    // signal there's a new empty space

    sem_post(&g_full_sem);
  }

  pthread_exit(0);
} /* consumer() */

/*
 * create threads and populate arrays
 * used for waiting on the threads
 * as well as protect again race conditions
 */

void create_threads(pthread_t ***thread_arr_ptr, int num_prod, int num_con) {
  pthread_t **thread_arr = *(thread_arr_ptr);

  // dynamically allocate an array of pointers to the pthreads
  // so that they may be kept track of to wait on at the end

  int tarr_len = (num_con + num_prod);
  int tarr_ents = 0;

  for (int i = 0; i < num_prod; ++i) {
    pthread_t *thread = (pthread_t *) malloc(sizeof(pthread_t));

    if (thread == NULL) {
      perror("malloc");
      exit(1);
    }

    if (tarr_ents >= tarr_len) {
      fprintf(stderr, "error with thread arr\n");
      exit(1);
    }

    thread_arr[tarr_ents] = thread;
    ++tarr_ents;

    int *tnum = (int *) malloc(sizeof(int));

    if (tnum == NULL) {
      perror("malloc");
      exit(1);
    }

    *tnum = i;

    pthread_create(thread, NULL, (void * (*)(void *)) producer, (void *) tnum);
  }

  for (int j = 0; j < num_con; ++j) {
    // Producers should be numbered 0 to N, like the consumers

    pthread_t *thread = (pthread_t *) malloc(sizeof(pthread_t));

    if (thread == NULL) {
      perror("malloc");
      exit(1);
    }

    if (tarr_ents >= tarr_len) {
      fprintf(stderr, "error with thread arr\n");
      exit(1);
    }

    thread_arr[tarr_ents] = thread;
    ++tarr_ents;

    int *tnum = (int *) malloc(sizeof(int));

    if (tnum == NULL) {
      perror("malloc");
      exit(1);
    }

    *tnum = j;

    pthread_create(thread, NULL, (void * (*)(void *)) consumer, (void *) tnum);
  }
} /* create_threads() */

/*
 * Start a number of producers indicated by the first argument, and a number
 * of consumers indicated by the second argument.
 * Wait on all threads at the end to prevent premature exit.
 */

int main(int argc, char **argv) {
  if (argc != 3) {
    fprintf(stderr, "Please pass two arguments.\n");
    exit(1);
  }

  // Initialize the g_buffer_mutex and condition variables

  pthread_mutex_init(&g_buffer_mutex, NULL);

  // Since the g_buffer starts out with no characters,
  // g_empty_sem should be 0 and g_full_sem should be the full
  // size of the g_buffer.

  sem_init(&g_empty_sem, 0, 0);
  sem_init(&g_full_sem, 0, BUF_SIZE);

  // initialize bounded_buffer

  g_buffer.head = 0;
  g_buffer.tail = 0;

  // Add your code to create the threads.
  // Make sure to allocate and pass the arguments correctly.

  char *endptr = NULL;
  int num_prod = (int) strtol(argv[1], &endptr, 10);

  if (*endptr != '\0') {
    fprintf(stderr, "Invalid producer number.\n");
    exit(1);
  }

  int num_con = (int) strtol(argv[2], &endptr, 10);

  if (*endptr != '\0') {
    fprintf(stderr, "Invalid consumer number.\n");
    exit(1);
  }

  pthread_t **thread_arr = malloc((num_con + num_prod) * sizeof(pthread_t *));

  if (thread_arr == NULL) {
    perror("malloc");
    exit(1);
  }

  create_threads(&thread_arr, num_prod, num_con);

  // Add your code to wait for the threads to finish.
  // Otherwise main might run to the end
  // and kill the entire process when it exits.

  int tarr_len = num_prod + num_con;

  for (int i = 0; i < tarr_len; ++i) {
    pthread_t thread = *thread_arr[i];
    pthread_join(thread, NULL);
  }

  for (int i = 0; i < tarr_len; ++i) {
    free(thread_arr[i]);
  }

  free(thread_arr);

  pthread_mutex_destroy(&g_buffer_mutex);

  return 0;
} /* main() */
