#ifndef PART1_H
#define PART1_H

#define BUF_SIZE (32)

#include <pthread.h>

typedef struct {
  char queue[BUF_SIZE];
  int head;
  int tail;
} bounded_buffer;

void *producer(void *ptr);
void *consumer(void *ptr);
void create_threads(pthread_t ***thread_arr_ptr, int num_prod, int num_con);

#endif // PART1_H
