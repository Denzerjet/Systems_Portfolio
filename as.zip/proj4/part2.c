#include "part2.h"

#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// The number of molecules of each type
// (O, N, O2, and N2)

int g_num_oxygen = 0;
int g_num_nitrogen = 0;
int g_num_o2 = 0;
int g_num_n2 = 0;

bool g_oxygen_depleted = false;
bool g_nitrogen_depleted = false;
bool g_o2_depleted = false;
bool g_n2_depleted = false;

pthread_mutex_t g_atmosphere_mutex = { 0 };

sem_t g_o2_prereqs = { 0 };
sem_t g_n2_prereqs = { 0 };
sem_t g_no2_prereqs = { 0 };
sem_t g_o3_prereqs = { 0 };

/*
 * Create oxygen atoms. The number of atoms to create is specified by the
 * argument, which is an int cast to (void *).
 */

void *create_oxygen(void *ptr) {
  size_t how_many = *((int *) ptr);
  free(ptr);
  ptr = NULL;

  for (size_t i = 0; i < how_many; ++i) {
    // obtain lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // add to atmosphere

    ++g_num_oxygen;

    // Print this for each atom created:

    printf("An atom of oxygen was created.\n");

    // check if appro to signal higher level producers

    if (g_num_oxygen % 2 == 0) {
      // this means the number of oxygen has just reached
      // an even number, so signal a higher level producer

      sem_post(&g_o2_prereqs);
    }

    // if last oxygen, signal to producers

    if (i == how_many - 1) {
      g_oxygen_depleted = true;
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }

  // on exit signal to higher level producers
  // to give them a chance to exit

  sem_post(&g_o2_prereqs);
  pthread_exit(0);
} /* create_oxygen() */

/*
 * Create nitrogen atoms. The number of atoms to create is specified by the
 * argument, which is an int cast to (void *).
 */

void *create_nitrogen(void *ptr) {
  size_t how_many = *((int *) ptr);
  free(ptr);
  ptr = NULL;

  for (size_t i = 0; i < how_many; ++i) {
    // obtain lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // add to atmosphere

    ++g_num_nitrogen;

    // Print this for each atom created:

    printf("An atom of nitrogen was created.\n");

    // check if appro to signal higher level producers

    if (g_num_nitrogen % 2 == 0) {
      // this means the number of oxygen has just reached
      // an even number, so signal a higher level producer

      sem_post(&g_n2_prereqs);
    }

    // if last nitrogen, signal producers

    if (i == how_many - 1) {
      g_nitrogen_depleted = true;
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }

  sem_post(&g_n2_prereqs);
  pthread_exit(0);
} /* create_nitrogen() */

/*
 * Form N2 molecules, by combining nitrogen atoms.
 */

void *create_n2(void *ptr) {
  (void) (ptr);

  // remember to check if depleted, then close the thread

  while (1) {
    // wait for n2 signal

    sem_wait(&g_n2_prereqs);

    // obtain lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // double check vals of n

    if (g_num_nitrogen < 2) {
      if (g_nitrogen_depleted) {
        pthread_mutex_unlock(&g_atmosphere_mutex);
        pthread_exit(0);
      }

      pthread_mutex_unlock(&g_atmosphere_mutex);
      continue;
    }

    // create n2 and reduce n

    ++g_num_n2;
    g_num_nitrogen -= 2;

    // print

    printf("Two atoms of nitrogen combined to produce one molecule of N2.\n");

    // check atmosphere, signal higher level producer if prereqs met

    if ((g_num_n2 * 2 <= g_num_o2) && (g_num_o2 > 0)) {
      // minimally signal higher level producer

      sem_post(&g_no2_prereqs);
    }

    // check if n depleted

    if ((g_nitrogen_depleted) && (g_num_nitrogen < 2)) {
      g_n2_depleted = true;
      pthread_mutex_unlock(&g_atmosphere_mutex);
      sem_post(&g_no2_prereqs);
      pthread_exit(0);
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }
} /* create_n2() */

/*
 * Form O2 molecules, by combining oxygen atoms.
 */

void *create_o2(void *ptr) {
  (void) (ptr);

  while (1) {
    // wait for o2 signal

    sem_wait(&g_o2_prereqs);

    // obtain lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // double check vals of o

    if (g_num_oxygen < 2) {
      if (g_oxygen_depleted) {
        pthread_mutex_unlock(&g_atmosphere_mutex);
        pthread_exit(0);
      }

      pthread_mutex_unlock(&g_atmosphere_mutex);
      continue;
    }

    // create n2 and reduce n

    ++g_num_o2;
    g_num_oxygen -= 2;

    // print

    printf("Two atoms of oxygen combined to produce one molecule of O2.\n");

    // check atmosphere, signal higher level producer if prereqs met

    if ((g_num_o2 <= g_num_n2 * 2) && (g_num_n2 > 0)) {
      // minimally signal higher level producer

      sem_post(&g_no2_prereqs);
    }

    if (g_num_o2 > 2) {
      sem_post(&g_o3_prereqs);
    }

    // check if o depleted

    if ((g_oxygen_depleted) && (g_num_oxygen < 2)) {
      g_o2_depleted = true;
      pthread_mutex_unlock(&g_atmosphere_mutex);
      sem_post(&g_no2_prereqs);
      sem_post(&g_o3_prereqs);
      pthread_exit(0);
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }
} /* create_o2() */

/*
 * Form NO2 molecules, by combining N2 and O2 molecules.
 */

void *create_no2(void *ptr) {
  (void) (ptr);

  while (1) {
    // wait for signal

    sem_wait(&g_no2_prereqs);

    // aquire lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // double check atmosphere conditions

    if ((g_num_n2 < 1) || (g_num_o2 < 2)) {
      if (((g_o2_depleted) && (g_num_o2 < 2)) ||
          ((g_n2_depleted) && (g_num_n2 < 1))) {
        pthread_mutex_unlock(&g_atmosphere_mutex);
        pthread_exit(0);
      }

      pthread_mutex_unlock(&g_atmosphere_mutex);
      continue;
    }

    // create 2 NO2 and consume 1 N2 and 2 O2
    // no need for an no2 global

    --g_num_n2;
    g_num_o2 -= 2;

    // print

    printf("One molecule of N2 and two molecules of O2 combined to "
           "produce two molecules of NO2.\n");

    // check if n2 or o2 depleted and not enough of them is left

    if (((g_o2_depleted) && (g_num_o2 < 2)) ||
        ((g_n2_depleted) && (g_num_n2 < 1))) {
      pthread_mutex_unlock(&g_atmosphere_mutex);
      pthread_exit(0);
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }
} /* create_no2() */

/*
 * Form O3 molecules, by combining O2 molecules.
 */

void *create_o3(void *ptr) {
  (void) (ptr);

  while (1) {
    // wait for signal

    sem_wait(&g_o3_prereqs);

    // aquire lock

    pthread_mutex_lock(&g_atmosphere_mutex);

    // double check atmosphere conditions

    if (g_num_o2 < 3) {
      if (g_o2_depleted) {
        pthread_mutex_unlock(&g_atmosphere_mutex);
        pthread_exit(0);
      }

      pthread_mutex_unlock(&g_atmosphere_mutex);
      continue;
    }

    // create 1 O3 and consume 3 O2
    // no need for an o3 global

    g_num_o2 -= 3;

    // print

    printf("Three molecules of O2 combined to produce two molecules of O3.\n");

    // check if o2

    if ((g_o2_depleted) && (g_num_o2 < 3)) {
      pthread_mutex_unlock(&g_atmosphere_mutex);
      pthread_exit(0);
    }

    // unlock

    pthread_mutex_unlock(&g_atmosphere_mutex);
  }
} /* create_o3() */

/*
 * Function to spawn the threads
 * for the producers
 */

void create_threads(pthread_t ***thread_arr_ptr, size_t oxygen_count,
                    size_t nitrogen_count) {
  pthread_t **thread_arr = *(thread_arr_ptr);

  for (int i = 0; i < (int) NUM_THREADS; ++i) {
    pthread_t *thread = malloc(sizeof(pthread_t));

    if (thread == NULL) {
      perror("malloc");
      exit(1);
    }

    thread_arr[i] = thread;

    if (i < 2) {
      int *count_arg = (int *) malloc(sizeof(int));

      if (count_arg == NULL) {
        perror("malloc");
        exit(1);
      }

      if (i == 0) {
        *count_arg = oxygen_count;
        pthread_create(thread, NULL,
                       (void * (*)(void *)) create_oxygen,
                       (void *) count_arg);
      }
      else {
        *count_arg = nitrogen_count;
        pthread_create(thread, NULL,
                       (void * (*)(void *)) create_nitrogen,
                       (void *) count_arg);
      }
    }
    else {
      switch (i) {
        case 2:
          pthread_create(thread, NULL,
                         (void * (*)(void *)) create_n2,
                         NULL);
          break;
        case 3:
          pthread_create(thread, NULL,
                         (void * (*)(void *)) create_o2,
                         NULL);
          break;
        case 4:
          pthread_create(thread, NULL,
                         (void * (*)(void *)) create_no2,
                         NULL);
          break;
        case 5:
          pthread_create(thread, NULL,
                         (void * (*)(void *)) create_o3,
                         NULL);
          break;
        default:
          fprintf(stderr, "Error spawning threads.\n");
          exit(1);
      }
    }
  }
} /* create_threads() */


/*
 * Create threads to run each chemical reaction. Wait on all threads to avoid
 * any premature exit. The number of oxygen atoms to be created is specified by
 * the first command-line argument, and the number of nitrogen atoms with the
 * second.
 */

int main(int argc, char **argv) {
  if (argc != 3) {
    fprintf(stderr, "Please pass two arguments.\n");
    exit(1);
  }

  // initialize mutex

  pthread_mutex_init(&g_atmosphere_mutex, NULL);

  // initialize semaphores

  sem_init(&g_o2_prereqs, 0, 0);
  sem_init(&g_n2_prereqs, 0, 0);
  sem_init(&g_no2_prereqs, 0, 0);
  sem_init(&g_o3_prereqs, 0, 0);

  char *endptr = NULL;
  size_t oxygen_count = (size_t) strtol(argv[1], &endptr, 10);

  if (*endptr != '\0') {
    fprintf(stderr, "Invalid producer number.\n");
    exit(1);
  }

  size_t nitrogen_count = (size_t) strtol(argv[2], &endptr, 10);

  if (*endptr != '\0') {
    fprintf(stderr, "Invalid nitrogen count.\n");
    exit(1);
  }

  pthread_t **thread_arr = malloc((int) NUM_THREADS * sizeof(pthread_t *));

  if (thread_arr == NULL) {
    perror("malloc");
    exit(1);
  }

  create_threads(&thread_arr, oxygen_count, nitrogen_count);

  // Add your code to wait till threads are complete before main
  // continues. Unless we wait we run the risk of executing an exit which will
  // terminate the process and all threads before the threads have completed.

  for (int i = 0; i < (int) NUM_THREADS; ++i) {
    pthread_t thread = *(thread_arr[i]);
    pthread_join(thread, NULL);
  }

  for (int i = 0; i < (int) NUM_THREADS; ++i) {
    free(thread_arr[i]);
  }

  free(thread_arr);

  pthread_mutex_destroy(&g_atmosphere_mutex);

  exit(EXIT_SUCCESS);
} /* main() */
