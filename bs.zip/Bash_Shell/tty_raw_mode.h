#ifndef TTY_RAW_MODE_H
#define TTY_RAW_MODE_H

void tty_raw_mode(void);

#endif // TTY_RAW_MODE_H
