#include "main.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "handlers.h"
#include "server.h"
#include "socket.h"

#define DEFAULT_PORT (1064)

acceptor *g_acceptor = NULL;

/*
 * Print the usage for the program. Takes the name
 * of the program as an argument
 * the return value is just for
 * trying to allow the linter to run properly
 */

int print_default_usage(char *v_name) {
  printf("USAGE: %s [-f|-t|-pNUM_THREADS] [-h] PORT_NO\n", v_name);

  return 0;
} /* print_default_usage() */

/*
 * does nothing, used as callback
 * for SIGPIPE where we just restart
 */

void do_nothing(int signum) { (void)signum; } /* do_nothing() */

/*
 * frees memory and closes fds
 */

void clean_exit(int signum) {
  (void)signum;

  if (close(g_acceptor->master_socket)) {
    perror("close");
    exit(1);
  }

  if (g_child_list != NULL) {
    free(g_child_list);
    g_child_list = NULL;
  }

  if (g_acceptor != NULL) {
    close_socket_acceptor(g_acceptor);
  }

  if (strlen(g_cached_auth) != 0) {
    free(g_cached_auth);
    g_cached_auth = NULL;
  }

  exit(0);

} /* clean_exit() */

/*
 * collects zombies
 */

void child_collector(int signum) {
  (void)signum;

  int pid = -1;

  while ((pid = waitpid(-1, NULL, WNOHANG) > 0)) {
    // collect the children!!!

    (void)NULL;
  }
} /* zombie_collector() */

/*
 * Runs the webserver.
 */

int main(int argc, char **argv) {
  // default to linear

  struct sigaction signal_action = {
      .sa_handler = child_collector, .sa_mask = 0, .sa_flags = SA_RESTART};

  sigemptyset(&signal_action.sa_mask);

  if (sigaction(SIGCHLD, &signal_action, NULL)) {
    perror("sigaction");
    exit(1);
  }

  struct sigaction signal_exit = {
      .sa_handler = clean_exit, .sa_mask = 0, .sa_flags = 0};

  sigemptyset(&signal_exit.sa_mask);

  if (sigaction(SIGINT, &signal_exit, NULL)) {
    perror("sigaction");
    exit(1);
  }

  if (sigaction(SIGUSR1, &signal_exit, NULL)) {
    perror("sigaction");
    exit(1);
  }

  struct sigaction handle_sigpipe = {
      .sa_handler = do_nothing, .sa_mask = 0, .sa_flags = SA_RESTART};

  sigemptyset(&signal_action.sa_mask);

  if (sigaction(SIGPIPE, &handle_sigpipe, NULL)) {
    perror("sigaction");
    exit(1);
  }

  concurrency_mode v_mode = E_NO_CONCURRENCY;

  int port_no = 0;
  int num_threads = 0;

  int c = 0;
  while ((c = getopt(argc, argv, "hftp:")) != -1) {
    switch (c) {
    case 'h':
      print_default_usage(argv[0]);
      return 0;
    case 'f':
    case 't':
    case 'p':
      if (v_mode != E_NO_CONCURRENCY) {
        fputs("Multiple concurrency modes specified\n", stdout);
        print_default_usage(argv[0]);
        return -1;
      }
      v_mode = (concurrency_mode)c;
      if (v_mode == E_THREAD_POOL) {
        num_threads = atoi(optarg);
      }
      break;
    case '?':
      if (isprint(optopt)) {
        fprintf(stderr, "Unknown option: -%c\n", optopt);
      } else {
        fprintf(stderr, "Unknown option\n");
      }
    default:
      print_default_usage(argv[0]);
      return 1;
    }
  }

  if (optind > argc) {
    fprintf(stderr, "Extra arguments were specified");
    print_default_usage(argv[0]);
    return 1;
  } else if (optind == argc) {
    // use default port

    port_no = DEFAULT_PORT;
  } else {
    port_no = atoi(argv[optind]);
  }

  g_acceptor = create_socket_acceptor(port_no);
  acceptor *acceptor = g_acceptor;

  if (acceptor == NULL) {
    return 1;
  }

  switch (v_mode) {
  case E_FORK_PER_REQUEST:
    run_forking_server(acceptor);
    break;
  case E_THREAD_PER_REQUEST:
    run_threaded_server(acceptor);
    break;
  case E_THREAD_POOL:
    run_thread_pool_server(acceptor, num_threads);
    break;
  default:
    run_linear_server(acceptor);
    break;
  }

  close_socket_acceptor(acceptor);

  return 0;
} /* main() */
