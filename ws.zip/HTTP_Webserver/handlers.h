#ifndef HANDLERS_H
#define HANDLERS_H

#include "http_messages.h"

#include <stddef.h>

#define MAX_NUM_LEN (20)

extern char *g_cached_auth;
extern char **g_downloaded_modules;
extern int num_modules;

char *handle_htdocs(const http_request *request, int *len);
char *handle_cgi_bin(const http_request *request, int socket_fd, int *ret_len);
int parse_method(const char *buf, http_request *request);
int parse_request_uri(const char *buf, http_request *request);
int parse_http_version(const char *buf, http_request *request);
int parse_headers(const char *buf, http_request *request);
int check_auth(http_request *request);
char *base64_encode(const unsigned char *data, size_t input_length,
                    size_t *output_length);
char *form_request_auth();
int request_auth(http_response *response);
char *form_response_string(http_response *response);
char *form_bad_request();
char *form_method_disallowed();
int vet_filename(char *filename);
int file_tester(char *filename);
char *form_not_found();
char *form_forbidden();
char *form_not_supported();
int find_file_len(char *filename);
void free_http_request(http_request *request);
char *serve_directory(char *directory_name, int socket_fd);

#endif // HANDLERS_H
