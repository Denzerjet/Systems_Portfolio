#include "http_messages.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "handlers.h"

/*
 * Return the reason string for a particular status code.
 * (not used)
 */

const char *status_reason(int status) {
  switch (status) {
  case 100:
    return "Continue";
  case 101:
    return "Switching Protocols";
  case 200:
    return "OK";
  case 201:
    return "Created";
  case 202:
    return "Accepted";
  case 203:
    return "Non-Authoritative Information";
  case 204:
    return "No Content";
  case 205:
    return "Reset Content";
  case 206:
    return "Partial Content";
  case 300:
    return "Multiple Choices";
  case 301:
    return "Moved Permanently";
  case 302:
    return "Found";
  case 303:
    return "See Other";
  case 304:
    return "Not Modified";
  case 305:
    return "Use Proxy";
  case 307:
    return "Temporary Redirect";
  case 400:
    return "Bad Request";
  case 401:
    return "Unauthorized";
  case 402:
    return "Payment Required";
  case 403:
    return "Forbidden";
  case 404:
    return "Not Found";
  case 405:
    return "Method Not Allowed";
  case 406:
    return "Not Acceptable";
  case 407:
    return "Proxy Authentication Required";
  case 408:
    return "Request Time-out";
  case 409:
    return "Conflict";
  case 410:
    return "Gone";
  case 411:
    return "Length Required";
  case 412:
    return "Precondition Failed";
  case 413:
    return "Request Entity Too Large";
  case 414:
    return "Request-URI Too Large";
  case 415:
    return "Unsupported Media Type";
  case 416:
    return "Requested range not satisfiable";
  case 417:
    return "Expectation Failed";
  case 500:
    return "Internal Server Error";
  case 501:
    return "Not Implemented";
  case 502:
    return "Bad Gateway";
  case 503:
    return "Service Unavailable";
  case 504:
    return "Gateway Time-out";
  case 505:
    return "HTTP Version Not Supported";
  default:
    return "Unknown status";
  }
} /* status_reason() */

/*
 * Create the actual response string to be sent over the socket.
 * Allocates a string that contains the response to send back.
 * returns NULL for internal failures
 */

char *response_string(http_response *response, http_request *request, int *len,
                      int socket_fd) {
  // FIRST: must check for BAD_REQUEST

  if (request->status == BAD_REQUEST) {
    return form_bad_request();
  }

  // SECOND: check for authorization

  int ret = check_auth(request);

  if (ret == -1) {
    // authorization failed

    char *req_auth_str = form_request_auth();

    return req_auth_str;
  } else if (ret == INTERNAL_SERVER_ERROR) {
    return NULL;
  }

  // THEN, the rest
  // check BAD_REQUEST, INTERNAL_ERROR, METHOD_NOT_FOUND
  // before doing the rest as they would've been set already

  switch (request->status) {
  case BAD_REQUEST:
    // char *bad_resp = form_bad_request();

    return form_bad_request();
  case INTERNAL_SERVER_ERROR:
    return NULL;
  case METHOD_NOT_ALLOWED:
    // char *disallowed_resp = form_method_disallowed();

    return form_method_disallowed();
  case HTTP_VERSION_NOT_SUPPORTED:
    return form_not_supported();
  default:
    // do nothing

    (void)NULL;
  }

  // populate it based on htdocs or cgi_bin request

  char *resp_str = NULL;

  if ((request->request_uri[strlen(request->request_uri) - 1] == '/') &&
      (strlen(request->request_uri) != 1)) {
    return serve_directory(request->request_uri, socket_fd);
  }

  if (strncmp("/cgi-bin", request->request_uri, strlen("/cgi-bin")) == 0) {
    resp_str = handle_cgi_bin(request, socket_fd, len);
  } else {
    resp_str = handle_htdocs(request, len);
  }

  return resp_str;
} /* response_string() */

/*
 * Parse an http request and populates fields in an http_request struct
 * buf: pointer to an http request (string)
 * request: pointer to an http_request struct to fill out
 * Return 0 on success
 * Return -1 on error
 */

int parse_request(const char *buf, http_request *request) {
  if (!buf) {
    return -1;
  }

  request->status = -1;

  // I am not sure that we use message body for requests
  // in this lab.
  // I can add this later

  request->message_body = "";
  request->query = "";

  int ret = parse_method(buf, request);

  switch (ret) {
  case BAD_REQUEST:
    request->status = BAD_REQUEST;
    return BAD_REQUEST;
  case METHOD_NOT_ALLOWED:
    request->status = METHOD_NOT_ALLOWED;
    break;
  case INTERNAL_SERVER_ERROR:
    request->status = INTERNAL_SERVER_ERROR;
    break;
  default:
    // successful, do nothing

    (void)NULL;
  }

  ret = parse_request_uri(buf, request);

  switch (ret) {
  case BAD_REQUEST:
    request->status = BAD_REQUEST;
    return BAD_REQUEST;
    // break;
  case INTERNAL_SERVER_ERROR:
    request->status = INTERNAL_SERVER_ERROR;
    break;
  default:
    // do nothing

    (void)NULL;
  }

  ret = parse_http_version(buf, request);

  switch (ret) {
  case BAD_REQUEST:
    request->status = BAD_REQUEST;
    return BAD_REQUEST;
    // break;
  case INTERNAL_SERVER_ERROR:
    request->status = INTERNAL_SERVER_ERROR;
    break;
  case HTTP_VERSION_NOT_SUPPORTED:
    request->status = HTTP_VERSION_NOT_SUPPORTED;
    break;
  default:
    // do nothing

    (void)NULL;
  }

  // request->num_headers = 0;

  ret = parse_headers(buf, request);

  switch (ret) {
  case BAD_REQUEST:
    request->status = BAD_REQUEST;
    return BAD_REQUEST;
    // break;
  case INTERNAL_SERVER_ERROR:
    request->status = INTERNAL_SERVER_ERROR;
    break;
  default:
    // do nothing

    (void)NULL;
  }

  return OK;
} /* parse_request() */

/*
 * Print the request to stdout for debugging.
 */

void print_request(http_request *request) {
  printf("REQ\n");

  printf("Method: {%s}\n", request->method);
  printf("Request URI: {%s}\n", request->request_uri);
  printf("Query string: {%s}\n", request->query);
  printf("HTTP Version: {%s}\n", request->http_version);

  printf("Headers: \n");
  for (int i = 0; i < request->num_headers; i++) {
    printf("field-name: %s; field-value: %s\n", request->headers[i]->key,
           request->headers[i]->value);
  }

  printf("Message body length: %ld\n", strlen(request->message_body));
  printf("%s\n", request->message_body);

  // Magic string to help with autograder

  printf("END REQ\n");
} /* print_request() */
