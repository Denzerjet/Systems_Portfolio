#include "tls.h"

#include <errno.h>
#include <openssl/err.h>
#include <unistd.h>

/*
 * Inits SLL
 */

void init_openssl() {
  SSL_load_error_strings();
  OpenSSL_add_ssl_algorithms();
} /* init_openssl() */

/*
 * creates an SSL context
 */

SSL_CTX *create_context() {
  const SSL_METHOD *v_method = TLS_server_method();
  SSL_CTX *v_ctx = SSL_CTX_new(v_method);
  if (!v_ctx) {
    perror("Unable to create SSL context");
    ERR_print_errors_fp(stderr);
    exit(EXIT_FAILURE);
  }

  return v_ctx;
} /* create_context() */

/*
 * Configure an ssl context
 */

void configure_context(SSL_CTX *ctx) {
  SSL_CTX_set_ecdh_auto(ctx, 1);

  if (SSL_CTX_use_certificate_file(ctx, "cert.pem", SSL_FILETYPE_PEM) <= 0) {
    ERR_print_errors_fp(stderr);
    exit(EXIT_FAILURE);
  }

  if (SSL_CTX_use_PrivateKey_file(ctx, "key.pem", SSL_FILETYPE_PEM) <= 0) {
    ERR_print_errors_fp(stderr);
    exit(EXIT_FAILURE);
  }
} /* configure_context() */

/*
 * Close and free a TLS socket created by accept_tls_connection(). Return 0 on
 * success.
 */

int close_tls_socket(tls_socket *socket) {
  SSL_free(socket->ssl);
  socket->ssl = NULL;

  if (close(socket->socket_fd) < 0) {
    perror("close");
    return -1;
  }

  free(socket);

  return -1;
} /* close_tls_socket() */

/*
 * Read a buffer of length buf_len from the TLS socket. Return the length of the
 * message on successful completion.
 */

int tls_read(tls_socket *socket, char *buf, size_t buf_len) {
  if (buf == NULL) {
    return -1;
  } else {
    int r = SSL_read(socket->ssl, buf, buf_len);
    if (r == -1) {
      fprintf(stderr, "Unable to read a character\n");
      return r;
    }
    return r;
  }
} /* tls_read() */

/*
 * Write a buffer of length buf_len to the TLS socket. Return 0 on success.
 */

int tls_write(tls_socket *socket, char *buf, size_t buf_len) {
  if (buf == NULL) {
    return -1;
  }

  size_t sent = SSL_write(socket->ssl, buf, buf_len);
  if (sent < 0) {
    return sent;
  } else if (sent != buf_len) {
    fprintf(stderr,
            "Could not write all bytes using"
            "ssl_write. Expected %ld but actually sent"
            "%ld\n",
            buf_len, sent);
    return -1;
  }

  return 0;
} /* tls_write() */

/*
 * Create a new TLS socket acceptor, listening on the given port. Return NULL on
 * error.
 */

tls_acceptor *create_tls_acceptor(int port) {
  init_openssl();
  SSL_CTX *ctx = create_context();
  configure_context(ctx);

  tls_acceptor *acceptor = malloc(sizeof(tls_acceptor));

  acceptor->addr.sin_family = AF_INET;
  acceptor->addr.sin_port = htons(port);

  acceptor->addr.sin_addr.s_addr = htonl(INADDR_ANY);

  acceptor->master_socket = socket(AF_INET, SOCK_STREAM, 0);
  if (acceptor->master_socket < 0) {
    fprintf(stderr, "Unable to create socket: %s\n", strerror(errno));
    return NULL;
  }

  int optval = 1;
  if (setsockopt(acceptor->master_socket, SOL_SOCKET, SO_REUSEADDR, &optval,
                 sizeof(optval)) < 0) {
    fprintf(stderr, "Unable to set socket options: %s\n", strerror(errno));
  }
  if (bind(acceptor->master_socket, (struct sockaddr *)&acceptor->addr,
           sizeof(acceptor->addr)) < 0) {
    fprintf(stderr, "Unable to bind to socket: %s\n", strerror(errno));
  }

  if (listen(acceptor->master_socket, 50) < 0) {
    fprintf(stderr, "Unable to listen to socket: %s\n", strerror(errno));
  }

  acceptor->ssl_ctx = ctx;

  return acceptor;
} /* create_tls_acceptor() */

/*
 * Accept a new connection from the TLS socket acceptor. Return NULL on error,
 * and the new TLS socket otherwise.
 */

tls_socket *accept_tls_connection(tls_acceptor *acceptor) {
  struct sockaddr_in addr = {0};
  socklen_t addr_len = sizeof(addr);
  int socket_fd =
      accept(acceptor->master_socket, (struct sockaddr *)&addr, &addr_len);
  if (socket_fd == -1) {
    fprintf(stderr, "Unable to accept connection: %s\n", strerror(errno));
    return NULL;
  }

  tls_socket *socket = malloc(sizeof(tls_socket));
  socket->socket_fd = socket_fd;
  socket->addr = addr;

  char inet_pres[INET_ADDRSTRLEN];
  if (inet_ntop(addr.sin_family, &(addr.sin_addr), inet_pres,
                INET_ADDRSTRLEN)) {
    printf("Received a connection from %s\n", inet_pres);
  }

  // ssl stuff

  SSL *ssl = SSL_new(acceptor->ssl_ctx);
  SSL_set_fd(ssl, socket->socket_fd);

  if (SSL_accept(ssl) <= 0) {
    ERR_print_errors_fp(stderr);
  }

  socket->ssl = ssl;

  // end of ssl stuff

  return socket;
} /* accept_tls_connection() */

/*
 * Close and free the passed TLS socket acceptor. Return 0 on success.
 */

int close_tls_acceptor(tls_acceptor *acceptor) {
  SSL_CTX_free(acceptor->ssl_ctx);
  acceptor->ssl_ctx = NULL;

  int status = close(acceptor->master_socket);
  free(acceptor);
  acceptor = NULL;
  return status;
} /* close_tls_acceptor() */
