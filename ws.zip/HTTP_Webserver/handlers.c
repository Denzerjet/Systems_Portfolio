#include "handlers.h"

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "misc.h"
#include "server.h"

#define PAGE_SIZE (5000)

char *g_cached_auth = "";

static char g_encoding_table[] = {
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'};

static int g_mod_table[] = {0, 2, 1};

char **g_downloaded_modules = NULL;
int g_num_modules = 0;

/*
 * Handles a request for a document page.
 * Creates a response in the form of a string accordingly.
 * If an error occurs, return NULL.
 */

char *handle_htdocs(const http_request *request, int *len) {
  // for INTERNAL_SERVER_ERROR just return NULL
  // that is what is expected by the caller

  char *requested_resource = request->request_uri;
  int last_char_ind = strlen(requested_resource) - 1;
  char *req_rsc_exp = NULL;

  // if the req is for dir/ then serve dir/index.html
  // no reqs for dir without a / now, that is p2

  // serve a file

  if (requested_resource[last_char_ind] == '/') {
    // append index.html to it

    int exp_len = strlen(requested_resource) + strlen("index.html") + 1;
    req_rsc_exp = (char *)malloc(sizeof(char) * exp_len);

    if (req_rsc_exp == NULL) {
      return NULL;
    }

    strcpy(req_rsc_exp, requested_resource);
    strcpy(req_rsc_exp + strlen(requested_resource), "index.html");
    req_rsc_exp[exp_len - 1] = '\0';
  } else {
    // use dup here so that we can
    // unambigiuously call free later

    req_rsc_exp = strdup(requested_resource);

    if (req_rsc_exp == NULL) {
      return NULL;
    }
  }

  // now prepend the http-root-dir
  // and free req_rsc_exp

  int final_len = strlen(req_rsc_exp) + strlen("./http-root-dir/htdocs") + 1;
  char *final_path = (char *)malloc(sizeof(char) * final_len);

  if (final_path == NULL) {
    return NULL;
  }

  strcpy(final_path, "./http-root-dir/htdocs");
  strcpy(final_path + strlen("./http-root-dir/htdocs"), req_rsc_exp);
  final_path[final_len - 1] = '\0';
  free(req_rsc_exp);
  req_rsc_exp = NULL;

  // need to make sure that what is passed into the above func
  // doesn't contain a malicious path

  if (vet_filename(final_path) == -1) {
    // pretend that we didn't find it

    return form_not_found();
  }

  // filename has been vetted, can use misc.h now
  // ret value of get_content_type is malloc'd
  // must free it later

  // have func to try and open file
  // if it has no read perms, have it ret -2
  // if it doesn't exist, have it ret -1
  // else have it ret a positive number

  int test_ret = file_tester(final_path);

  switch (test_ret) {
  case -2:
    return form_not_found();
  case -1:
    return form_forbidden();
  default:
    // good to go

    (void)NULL;
  }

  // have a static string for the beginning of a
  // valid request, append the content type
  // then append the data

  // find the length of the file

  int file_len = find_file_len(final_path);

  if (file_len == -1) {
    return NULL;
  }

  // create an appropriately sized pointer to store its
  // content

  char *file_content = malloc(sizeof(char) * (file_len + 1));

  if (file_content == NULL) {
    return NULL;
  }

  file_content[file_len] = '\0';

  // create an fd for the file

  int file_fd = open(final_path, O_RDONLY);

  if (file_fd < 0) {
    return NULL;
  }

  // use a read() call to store the contents in the ptr

  int ret = read(file_fd, file_content, (size_t)file_len);

  if (ret < 0) {
    return NULL;
  }

  if (close(file_fd) < 0) {
    return NULL;
  }

  // create a static string with the header of a response
  // to a valid request

  char head[] = "HTTP/1.1 200 OK\r\nConnection: close\r\n";

  // get the content-type
  // and append it to the string
  // (followed by \r\n\r\n)

  // the ret val of get_content_type() is
  // allocated

  char *content_type = get_content_type(final_path);

  if (content_type == NULL) {
    return NULL;
  }

  for (int i = 0; i < strlen(content_type); ++i) {
    if (content_type[i] == ';') {
      content_type[i] = '\0';
      break;
    }
  }

  // test if it is a .css

  char ending[4] = "";

  strncpy(ending, final_path + (strlen(final_path) - strlen(".css")),
          strlen(".css"));

  if (strcmp(ending, ".css") == 0) {
    free(content_type);
    content_type = strdup("text/css");

    if (content_type == NULL) {
      return NULL;
    }
  }

  free(final_path);
  final_path = NULL;

  // convert the length to a string

  char num_str[MAX_NUM_LEN] = "";

  if (sprintf(num_str, "%d", file_len) < 0) {
    return NULL;
  }

  int req_len =
      (strlen(head) + strlen("Content-Type: ") + strlen(content_type) +
       strlen("\r\n") + strlen("Content-Length: ") + strlen(num_str) +
       strlen("\r\n\r\n") + file_len);
  *len = req_len;

  (void)req_len;

  char *response_string =
      malloc(sizeof(char) *
             (strlen(head) + strlen("Content-Type: ") + strlen(content_type) +
              strlen("\r\n") + strlen("Content-Length: ") + strlen(num_str) +
              strlen("\r\n\r\n") + file_len + 1));

  if (response_string == NULL) {
    return NULL;
  }

  // copy over the head

  strncpy(response_string, head, strlen(head));

  // then append a content-type header

  strcpy(response_string + strlen(head), "Content-Type: ");

  int resp_tail = strlen(head) + strlen("Content-Type: ");

  strcpy(response_string + resp_tail, content_type);
  resp_tail += strlen(content_type);
  strcpy(response_string + resp_tail, "\r\n");
  resp_tail += strlen("\r\n");

  // append a content-length header

  strcpy(response_string + resp_tail, "Content-Length: ");
  resp_tail += strlen("Content-Length: ");
  strcpy(response_string + resp_tail, num_str);
  resp_tail += strlen(num_str);
  strcpy(response_string + resp_tail, "\r\n\r\n");
  resp_tail += strlen("\r\n\r\n");

  // append the content

  memcpy(response_string + resp_tail, file_content, file_len);

  // resp_tail += strlen(file_content);

  resp_tail += file_len;

  response_string[resp_tail] = '\0';

  // send that to the client

  // close and free
  free(file_content);
  free(content_type);

  return response_string;
} /* handle_htdocs() */

/*
 * Create a response for cgi-bin requests by running the cg-bin executable.
 * If an error occurs, return NULL.
 */

char *handle_cgi_bin(const http_request *request, int socket_fd, int *ret_len) {
  // the file is at [+relpath of http-root-dir...]
  // + request_uri from the start
  // to the ?, make sure the [+relpath] part doesn't
  // end in a slash

  int qmark_index = 0;
  bool no_query = false;

  while (request->request_uri[qmark_index] != '?') {
    ++qmark_index;

    if (qmark_index >= strlen(request->request_uri)) {
      // cgi bin request without query

      no_query = true;
      break;
    }
  }

  char *input_path = (char *)malloc(qmark_index + 1);

  if (input_path == NULL) {
    return NULL;
  }

  input_path[qmark_index] = '\0';

  strncpy(input_path, request->request_uri, qmark_index);

  // no forward slash at end of prepended path

  int final_len = qmark_index + strlen("./http-root-dir") + 1;

  char *final_path = (char *)malloc(final_len);

  if (final_path == NULL) {
    return NULL;
  }

  final_path[final_len - 1] = '\0';

  memcpy(final_path, "./http-root-dir", strlen("./http-root-dir"));

  strncpy(final_path + strlen("./http-root-dir"), input_path, qmark_index);

  free(input_path);
  input_path = NULL;

  int test_ret = file_tester(final_path);

  switch (test_ret) {
  case -2:
    return form_not_found();
  case -1:
    return form_forbidden();
  default:
    // good to go

    (void)NULL;
  }

  // set env var REQUEST_METHOD=GET
  // malloc for it
  // use setenv()
  // remember to unsetenv and free this region
  // after the child exits

  char *req_met_env = strdup("REQUEST_METHOD=GET");

  if (req_met_env == NULL) {
    return NULL;
  }

  if (putenv(req_met_env) != 0) {
    return NULL;
  }

  // set QUERY_STRING=(args after ?)

  char *query_str_env = NULL;

  if (no_query == false) {
    // request->request_uri
    // extract string from ? to end

    // this includes the len of null term

    int query_len = strlen(request->request_uri) - qmark_index;
    char *query = (char *)malloc(query_len);

    if (query == NULL) {
      return NULL;
    }

    query[query_len - 1] = '\0';

    strncpy(query, request->request_uri + qmark_index + 1, query_len - 1);
    int query_env_len = strlen(query) + strlen("QUERY_STRING=") + 1;
    query_str_env = (char *)malloc(query_env_len);

    if (query_str_env == NULL) {
      return NULL;
    }

    memcpy(query_str_env, "QUERY_STRING=", strlen("QUERY_STRING="));
    memcpy(query_str_env + strlen("QUERY_STRING="), query, strlen(query));
    query_str_env[query_env_len - 1] = '\0';

    free(query);

    if (putenv(query_str_env) != 0) {
      return NULL;
    }
  }

  // see if is a loadable module

  int fpath_len = strlen(final_path);
  char head_portion[] = "HTTP/1.1 200 OK\r\nConnection: close"
                        "\r\nServer: Server-Type\r\n";

  if ((final_path[fpath_len - 1] == 'o') &&
      (final_path[fpath_len - 2] == 's') &&
      (final_path[fpath_len - 3] == '.')) {
    // loadable module

    void *lib = dlopen(final_path, RTLD_LAZY);
    if (lib == NULL) {
      fprintf(stderr, "module not found\n");
      exit(1);
    }

    void (*hello_httprun)(int, const char *) =
        (void (*)(int, const char *))dlsym(lib, "httprun");

    if (hello_httprun == NULL) {
      perror("dlsym: httprun not found");
      exit(1);
    }

    write(socket_fd, head_portion, strlen(head_portion));

    if (query_str_env == NULL) {
      hello_httprun(socket_fd, "");
    } else {
      hello_httprun(socket_fd, query_str_env);
    }

    unsetenv("REQUEST_METHOD");
    free(req_met_env);
    req_met_env = NULL;

    return strdup("");
  }

  // STDOUT TO PIPE REWRITE

  int pipefds[2] = {-1, -1};

  if (pipe(pipefds) == -1) {
    return NULL;
  }

  // FILE *pipe_file = fdopen(pipefds[1], "w");

  // if (pipe_file == NULL) {
  // fprintf(stderr, "fdopen failure");
  //}

  // FILE *og_stdout = stdout;
  // stdout = pipe_file;

  // STDOUT TO PIPE REWRITE END

  // fork
  // store pid

  int pid = fork();

  if (pid < 0) {
    return NULL;
  }

  // redir output of child process to
  // socket->socket_fd

  // have child print a header
  // fflush(stdout)

  // tell the child to execute the script

  // STDOUT FILE REWRITE

  // FILE *sock_file = fdopen(socket_fd, "r+");

  // if (sock_file == NULL) {
  // fprintf(stderr, "fdopen failure");
  //}

  // FILE *og_stdout = stdout;
  // stdout = sock_file;

  // STDOUT FILE REWRITE END

  if (pid == 0) {
    // in child

    if (close(pipefds[0]) < 0) {
      fprintf(stderr, "close failure");
    }

    pipefds[0] = -1;

    // when the dup2 call here is removed the
    // test case fails

    // if (dup2(socket_fd, STDOUT_FILENO) < 0) {

    if (dup2(pipefds[1], STDOUT_FILENO) < 0) {
      fprintf(stderr, "dup2 failure\n");
    }

    // if (close(1) < 0) {
    //   fprintf(stderr, "close failure\n");
    // }

    // printf("HTTP/1.1 200 OK Document follows\r\nServer: Server-Type\r\n");

    // fflush(stdout);

    write(pipefds[1], head_portion, strlen(head_portion));

    // fprintf(stderr, "you shouldn't be here *stares*\n");

    // add an else here if for some reason it keeps going

    char *args[2] = {0};
    args[0] = final_path;
    args[1] = NULL;

    unsetenv("LANG");

    execv(final_path, args);

    // execv failure

    perror("execv");
    exit(1);
  }

  // waitpid, if it fails
  // it's alright the signal handler prob
  // got to it

  int prev_errno = errno;

  if (waitpid(pid, NULL, 0) == -1) {
    if (errno == ECHILD) {
      // signal handler picked it up

      errno = prev_errno;
    } else {
      perror("waitpid");
      return NULL;
    }
  }

  free(final_path);
  final_path = NULL;

  // STDOUT FILE RESTORE

  // fflush(stdout);

  // fclose(sock_file);

  if (close(pipefds[1]) == -1) {
    return NULL;
  }

  pipefds[1] = -1;

  // fclose(pipe_file);

  // fclose(sock_file);
  // stdout = og_stdout;

  // STDOUTFILE RESTORE END

  // unset environment variables and free strings
  // only free query_str_env if its non-null

  // return something that tells the caller(s) to just
  // do nothing and close the socket

  // can just return "" here
  // need to strdup("") b/c it gets freed in server.c

  // response was already written by the child

  // read from pipe and allocate a return value

  // char *success_resp = strdup("");

  char *success_resp = malloc((int)REQ_STR_LEN + 1);

  if (success_resp == NULL) {
    return NULL;
  }

  int total_len = (int)REQ_STR_LEN + 1;
  int total_bytes_read = 0;
  int bytes_read = -1;

  while ((bytes_read = read(pipefds[0], success_resp + total_bytes_read,
                            (int)REQ_STR_LEN)) > 0) {
    total_bytes_read += bytes_read;
    success_resp = realloc(success_resp, total_len + (int)REQ_STR_LEN);

    if (success_resp == NULL) {
      return NULL;
    }

    total_len += (int)REQ_STR_LEN;
  }

  if (bytes_read == -1) {
    return NULL;
  }

  if (close(pipefds[0]) < 0) {
    return NULL;
  }

  pipefds[0] = -1;

  success_resp[total_bytes_read] = '\0';

  *ret_len = total_bytes_read;

  // char *success_resp = strdup("");

  if (query_str_env != NULL) {
    unsetenv("QUERY_STRING");
    free(query_str_env);
    query_str_env = NULL;
  }

  unsetenv("REQUEST_METHOD");
  free(req_met_env);
  req_met_env = NULL;

  return success_resp;

} /* handle_cgi_bin() */

/*
 * Identifies the method section of a request
 * and populates the http_request struct accordingly
 * returns the appropriate status code
 */

int parse_method(const char *buf, http_request *request) {
  // identify and isolate section of buf
  // from the beginning to the first space
  // no CR or LF characters are allowed within this range
  // return an error if this is violated

  int start = 0;
  int end = 0;

  while ((end < (int)REQ_STR_LEN) && (buf[end] != ' ')) {
    // do not allow any <CR> or <LF> characters

    // <cr> and <lf> respectively

    if ((buf[end] == '\015') || (buf[end] == '\012')) {
      return BAD_REQUEST;
    }

    ++end;
  }

  if (end == (int)REQ_STR_LEN) {
    // if this reached the end of the buffer

    return BAD_REQUEST;
  }

  // this method can technically just check the first three
  // characters but this is more professional

  char *method = malloc(sizeof(char) * (end - start + 1));

  if (method == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  method[end - start] = '\0';

  strncpy(method, buf + start, end - start);

  if (strcmp(method, "GET")) {
    return METHOD_NOT_ALLOWED;
  }

  request->method = method;

  // return > 0 for success

  return OK;
} /* parse_method() */

/*
 * Parses the request_uri from a request
 * returns the appropriate status code
 */

int parse_request_uri(const char *buf, http_request *request) {
  int start = 0;

  while ((start < (int)REQ_STR_LEN) && (buf[start] != ' ')) {
    // no need to validate up to here, parse method would
    // have already
    ++start;
  }

  int end = start + 1;

  while ((end < (int)REQ_STR_LEN) && (buf[end] != ' ')) {
    // validate

    if ((buf[end] == '\015') || (buf[end] == '\012')) {
      return BAD_REQUEST;
    }

    ++end;
  }

  if (end == (int)REQ_STR_LEN) {
    return BAD_REQUEST;
  }

  // no plus one here, since end and start are the spaces
  // padding the request_uri

  char *request_uri = malloc(sizeof(char) * (end - start));

  if (request_uri == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  request_uri[end - start - 1] = '\0';

  // + 1 because start points to the space before the uri

  strncpy(request_uri, buf + start + 1, end - start - 1);
  request->request_uri = request_uri;

  return OK;
} /* parse_request_uri() */

/*
 * parse the http_version
 * returns the appropriate status code
 */

int parse_http_version(const char *buf, http_request *request) {
  // up to the first space after the request_uri is
  // already validated

  int first_space = 0;

  while (buf[first_space] != ' ') {
    ++first_space;
  }

  int start = first_space + 1;

  while (buf[start] != ' ') {
    ++start;
  }

  int end = start + 1;

  while ((end + 1 < (int)REQ_STR_LEN) && (buf[end] != '\015') &&
         (buf[end + 1] != '\012')) {
    ++end;
  }

  char *http_version = malloc(sizeof(char) * (end - start));

  if (http_version == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  http_version[end - start - 1] = '\0';

  strncpy(http_version, buf + start + 1, end - start - 1);

  request->http_version = http_version;

  if (strncmp(http_version, "HTTP", strlen("HTTP")) != 0) {
    // this is not an HTTP request
    // this is one of the few places where a malformed
    // request could slip by (though even without this
    // switch statement it would be HTTP_VERSION_NOT_SUPPORTED
    // This is because the format of an http request
    // must have the word HTTP here

    return BAD_REQUEST;
  }

  if ((strcmp(http_version, "HTTP/1.1") != 0) &&
      (strcmp(http_version, "HTTP/1.0") != 0)) {
    return HTTP_VERSION_NOT_SUPPORTED;
  }

  return OK;

} /* parse_http_version() */

/*
 * parses the headers
 * returns the appropriate status code
 */

int parse_headers(const char *buf, http_request *request) {
  // go to <cr> <lf>
  // then read up to the next space, that's the key
  // then read up to the next <cr><lf>, that's the value
  // store as a dynamically allocated header struct
  // store the ptr in request->headers (array of ptrs)
  // inc num_headers by 1

  // find indexes of first <cr><lf>

  request->num_headers = 0;

  int crlf = 0;

  // already validated to exist

  while ((buf[crlf] != '\015') && (buf[crlf] != '\012')) {
    ++crlf;
  }

  // add 1 b/c it went up to the cr

  ++crlf;

  // iteratively read until you find another crlf
  // check to see if the character after is a crlf
  // if so then exit loop
  // else read from crlf to the space, set as key
  // then read from the space to the next crlf
  // set that as the value
  // update the last crlf seen to read from there
  // loop

  int crlf_2 = crlf;

  request->headers = NULL;

  while (1) {
    while ((crlf_2 - 1 < (int)REQ_STR_LEN) && (buf[crlf_2] != '\015') &&
           (buf[crlf_2 + 1] != '\012')) {
      // finds the next crlf

      ++crlf_2;
    }

    ++crlf_2;

    if (crlf_2 - 2 == crlf) {
      // reached last header

      break;
    }

    if (crlf_2 - 1 >= (int)REQ_STR_LEN) {
      return BAD_REQUEST;
    }

    // dynamically allocate a header

    header *header_it = (header *)malloc(sizeof(header));

    if (header_it == NULL) {
      return INTERNAL_SERVER_ERROR;
    }

    // read from crlf to a space

    int space = crlf + 1;

    while ((space < (int)REQ_STR_LEN) && (buf[space] != ' ')) {
      ++space;
    }

    if (space == (int)REQ_STR_LEN) {
      // didn't find a space

      return BAD_REQUEST;
    }

    // store the key

    char *key = (char *)malloc(sizeof(char) * (space - crlf));

    if (key == NULL) {
      return INTERNAL_SERVER_ERROR;
    }

    key[space - crlf - 1] = '\0';
    strncpy(key, buf + crlf + 1, space - crlf - 1);
    header_it->key = key;

    // store the value
    // -1 here because crlf_2 points to the lf and not the cr

    char *value = (char *)malloc(sizeof(char) * (crlf_2 - space - 1));

    if (value == NULL) {
      free(key);
      key = NULL;
      return INTERNAL_SERVER_ERROR;
    }

    value[crlf_2 - space - 2] = '\0';
    strncpy(value, buf + space + 1, crlf_2 - space - 2);
    header_it->value = value;

    crlf = crlf_2;

    ++(request->num_headers);
    request->headers =
        realloc(request->headers, sizeof(header *) * request->num_headers);

    if (request->headers == NULL) {
      free(key);
      key = NULL;
      free(value);
      value = NULL;
      return INTERNAL_SERVER_ERROR;
    }

    request->headers[request->num_headers - 1] = header_it;
  }

  return OK;

} /* parse_headers() */

/*
 * checks authentication header of an http response
 * returning -1 if it fails
 * 1 if it passes
 * -1 if it fails
 * INTERNAL_SERVER_ERROR for malloc fails
 */

int check_auth(http_request *request) {
  // Authorization: Basic [...]

  // find auth header

  int auth_index = -1;

  for (int i = 0; i < request->num_headers; ++i) {
    if (!strcmp(request->headers[i]->key, "Authorization:")) {
      auth_index = i;
      break;
    }
  }

  if (auth_index == -1) {
    // no auth header found

    return -1;
  }

  // g_user_pass has the user and pass in plaintext

  char *auth_val = request->headers[auth_index]->value;

  // make sure the first bit of value is "Basic "

  if (strncmp(auth_val, "Basic ", strlen("Basic ")) != 0) {
    return -1;
  }

  // then check that the rem of the string is
  // equal to the base 64 encoding of the user:pass

  // isolate the authorization portion of the value

  int auth_len = strlen(auth_val) - strlen("Basic ");

  char *given_auth = malloc(sizeof(char) * (auth_len + 1));

  if (given_auth == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  strncpy(given_auth, auth_val + strlen("Basic "), auth_len + 1);

  // compute the encoded version of the true authorization

  if (strcmp(g_cached_auth, "") == 0) {
    // cache the result as a global to reduce computational
    // cost

    return_user_pwd_string();

    int max_len = (int)MAX_USR_PWD_LEN;

    // base64_encode mallocs for you

    g_cached_auth = base64_encode((const unsigned char *)g_user_pass,
                                  strlen(g_user_pass), (size_t *)&max_len);

    if (g_cached_auth == NULL) {
      return INTERNAL_SERVER_ERROR;
    }
  }

  // compare it with the passed in auth and return

  if (strcmp(g_cached_auth, given_auth) != 0) {
    free(given_auth);
    given_auth = NULL;

    return -1;
  }

  free(given_auth);
  given_auth = NULL;

  return 1;
} /* check_auth() */

/*
 * base 64 encoder from stackoverflow
 * https://stackoverflow.com/a/6782480
 * thank you ryyst!
 */

char *base64_encode(const unsigned char *data, size_t input_length,
                    size_t *output_length) {

  *output_length = 4 * ((input_length + 2) / 3);

  char *encoded_data = malloc(*output_length + 1);

  if (encoded_data == NULL) {
    return NULL;
  }

  int j = 0;
  for (int i = 0; i < input_length;) {
    uint32_t octet_a = i < input_length ? (unsigned char)data[i++] : 0;
    uint32_t octet_b = i < input_length ? (unsigned char)data[i++] : 0;
    uint32_t octet_c = i < input_length ? (unsigned char)data[i++] : 0;

    uint32_t triple = (octet_a << 0x10) + (octet_b << 0x08) + octet_c;

    encoded_data[j++] = g_encoding_table[(triple >> 3 * 6) & 0x3F];
    encoded_data[j++] = g_encoding_table[(triple >> 2 * 6) & 0x3F];
    encoded_data[j++] = g_encoding_table[(triple >> 1 * 6) & 0x3F];
    encoded_data[j++] = g_encoding_table[(triple >> 0 * 6) & 0x3F];
  }

  for (int i = 0; i < g_mod_table[input_length % 3]; i++) {
    encoded_data[*output_length - 1 - i] = '=';
  }

  encoded_data[*output_length] = '\0';

  return encoded_data;
} /* base64_encode() */

/*
 * returns a dynamically allocated
 * http response to an unauthorized request
 * returns null on internal failure
 */

char *form_request_auth() {
  // nevermind it is too time consuming to do it
  // by populating the struct itself

  char *response_string = strdup("HTTP/1.1 401 Unauthorized"
                                 "\r\nConnection: close\r\nWWW-Authenticate:"
                                 "Basic realm=\"kraft_mac_and_cheese\"\r\nCo"
                                 "ntent-Type: text/basic\r\nContent-Length: "
                                 "32\r\n\r\nPlease provide login credentials");

  return response_string;
} /* form_request_auth() */

/*
 * populates a http_response struct to request
 * authentication from the client
 * returns 1 on success
 * INTERNAL_SERVER_ERROR on malloc failure
 */

int request_auth(http_response *response) {
  // I can honestly just hard code this
  // but I won't b/c this is more professional

  char *http = strdup("HTTP/1.1");

  if (http == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  response->http_version = http;
  response->status_code = UNAUTHORIZED;
  char *unauth = strdup("UNAUTHORIZED");

  if (unauth == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  response->reason_phrase = unauth;
  header *connection_header = malloc(sizeof(header));

  if (connection_header == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  char *header_key = strdup("Connection:");

  if (header_key == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  connection_header->key = header_key;
  char *header_val = strdup("close");

  if (header_val == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  connection_header->value = header_val;
  (response->num_headers)++;
  response->headers =
      realloc(response->headers, sizeof(header *) * (response->num_headers));

  if (response->headers == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  response->headers[response->num_headers - 1] = connection_header;
  header *auth_header = malloc(sizeof(header));

  if (auth_header == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  char *auth_header_key = strdup("WWW-Authenticate:");

  if (auth_header_key == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  char *auth_header_val = strdup("Basic realm=\"kraft_mac_and_cheese\"");

  if (auth_header_val == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  auth_header->key = auth_header_key;
  auth_header->value = auth_header_val;

  (response->num_headers)++;
  response->headers =
      realloc(response->headers, sizeof(header *) * (response->num_headers));

  if (response->headers == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  response->headers[response->num_headers - 1] = auth_header;

  char *message_body = strdup("Please provide "
                              "login credentials to access this server");

  if (message_body == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  response->message_body = message_body;

  header *content_type = malloc(sizeof(header));

  if (content_type == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  char *type_key = strdup("Content-Type:");

  if (type_key == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  char *type_val = strdup("text/plain");

  if (type_val == NULL) {
    return INTERNAL_SERVER_ERROR;
  }

  return 1;
} /* request_auth() */

/*
 * forms a bad_request_response string
 */

char *form_bad_request() {
  char *response_string =
      strdup("HTTP/1.1 400 "
             "Bad Request\r\nConnection: close\r\n"
             "Content-Type: text/basic\r\n"
             "Content-Length: 21\r\n\r\nRequest was malformed");

  return response_string;
} /* form_bad_request() */

/*
 * forms a method not allowed response string
 */

char *form_method_disallowed() {
  char *response_string = strdup("HTTP/1.1 "
                                 "405 Method Not Allowed\r\nConnection: "
                                 "close\r\nContent-Type: text/basic\r\n"
                                 "Content-Length: 29\r\n\r\nThis "
                                 "server only supports GET");

  return response_string;
} /* form_method_disallowed() */

/*
 * vets a filename for malicious paths
 * 1 on success
 * -1 on failure
 */

int vet_filename(char *filename) {
  // check if it contains any dots, if in the calling func
  // say that the file doesn't exist
  // all spaces are also disallowed

  for (int i = 0; i < strlen(filename); ++i) {
    if ((filename[i] == ' ') ||
        ((filename[i] == '.') && (i > 0) && (filename[i - 1] == '.'))) {
      return -1;
    }
  }

  return 1;
} /* vet_filename() */

/*
 * checks to see if an file exists
 * and is readable
 * -2 if doesn't exist
 * -1 if unreadable
 * 1 if exists and is readable
 */

int file_tester(char *filename) {
  int saved_errno = errno;
  int fd = open(filename, O_RDONLY);

  if (fd > 0) {
    close(fd);
    return 1;
  }

  if (errno == EACCES) {
    errno = saved_errno;
    return -1;
  }

  errno = saved_errno;
  return -2;
} /* file_tester() */

/*
 * create a to_string for a 404
 */

char *form_not_found() {
  char *response_string = strdup("HTTP/1.1 "
                                 "404 Not Found\r\nConnection: close\r\n"
                                 "Content-Type: text/basic\r\nContent-Length:"
                                 "18\r\n\r\nResource not found");

  return response_string;
} /* form_not_found() */

/*
 * create a to_string for a 403
 */

char *form_forbidden() {
  char *response_string = strdup("HTTP/1.1 "
                                 "403 Forbidden\r\nConnection: close\r\n"
                                 "Content-Type: text/basic\r\nContent-Length:"
                                 "20\r\n\r\nAccess not permitted");

  return response_string;
} /* form_forbidden() */

/*
 * forms a to_string for
 * HTTP_VERSION_NOT_SUPPORTED
 */

char *form_not_supported() {
  char *response_string = strdup("HTTP/1.1 505 HTTP "
                                 "version not supported\r\nConnection: close"
                                 "\r\nContent-Type: text/basic\r\nContent:Len"
                                 "gth: 42\r\n\r\nThis server only supports "
                                 "http 1.0 and 1.1");

  return response_string;
} /* form_not_supported() */

/*
 * determines the length of a file
 * returns -1 on error
 */

int find_file_len(char *filename) {
  FILE *file = fopen(filename, "rb");

  if (file == NULL) {
    return -1;
  }

  fseek(file, 0, SEEK_END);
  int file_size = ftell(file);
  fclose(file);

  return file_size;
} /* find_file_len() */

/*
 * frees all fields of a http_request
 */

void free_http_request(http_request *request) {
  if (request == NULL) {
    return;
  }

  if (request->method != NULL) {
    free(request->method);
    request->method = NULL;
  }

  if (request->request_uri != NULL) {
    free(request->request_uri);
    request->request_uri = NULL;
  }

  if (request->http_version != NULL) {
    free(request->http_version);
    request->http_version = NULL;
  }

  for (int i = 0; i < request->num_headers; ++i) {
    if (request->headers[i] != NULL) {
      if (request->headers[i]->key != NULL) {
        free(request->headers[i]->key);
        request->headers[i]->key = NULL;
      }

      if (request->headers[i]->value != NULL) {
        free(request->headers[i]->value);
        request->headers[i]->value = NULL;
      }

      free(request->headers[i]);
      request->headers[i] = NULL;
    }
  }

  if (request->headers != NULL) {
    free(request->headers);
    request->headers = NULL;
  }

  if ((request->message_body != NULL) && (strlen(request->message_body) != 0)) {
    free(request->message_body);
    request->message_body = NULL;
  }

  if ((request->query != NULL) && (strlen(request->message_body) != 0)) {
    free(request->query);
  }

  free(request);
  request = NULL;
} /* free_http_request() */

/*
 * opens a downloadable module
 * if it exists and executes httprun for it
 */

int use_module(char *mod_path, int socket_fd, char *query_string) {
  // try to load module first
  // if query_string = NULL then pass in "" or something

  return -1;
} /* use_module() */

/*
 * serves a directory
 */

char *serve_directory(char *directory_name, int socket_fd) {
  /*
  char *page = (char *) malloc(PAGE_SIZE);
  int page_itr = 0;

  char block_one[] = "<!DOCTYPE html><html lang=\"en\"><head><title>Index of ";
  memcpy(page + page_itr, block_one, strlen(block_one));
  page_itr += strlen(block_one);

  memcpy(page + page_itr, directory_name, strlen(directory_name));
  page_itr += strlen(directory_name);

  char block_two[] = "</title></head><body><h1>Index of ";
  memcpy(page + page_itr, block_two, strlen(block_two));
  page_itr += strlen(block_two);

  memcpy(page + page_itr, directory_name, strlen(directory_name));
  page_itr += strlen(directory_name);

  char block_three[] = "</h1><table><tr><th>Name</th>"
    "<th>Last Modified</th><th>Size</th></tr><tr>"
    "<th colspan=\"3\"><hr></th></tr>";
  memcpy(page + page_itr, block_three, strlen(block_three));
  page_itr += strlen(block_three);

  char block_four[] = "<tr><td valign=\"top\"><img src="
    "\"/icons/back.gif\" alt=\"[PARENTDIR]\"></td><td><a href=\"";
  memcpy(page + page_itr, block_four, strlen(block_four));
  page_itr += strlen(block_four);

  char parent[] = "/index.html";
  memcpy(page + page_itr, parent, strlen(parent));
  page_itr += strlen(parent);

  char block_five[] = "\">Parent Directory</a></td><td>&nbsp;"
    "</td><td align=\"right\">-</td></tr>";
  memcpy(page + page_itr, block_five, strlen(block_five));
  page_itr += strlen(block_five);

  // Now the entries

  char entry_beg[] = "<tr><td valign=\"top\"><img src=\"";

  // /icons/back.gif

  char entry_two[] = "\" alt=\"[IMG]\"></td><td><a href=\"";

  // name of file

  char entry_three[] = "</a>               </td><td align=\"right\">";

  // last modified date

  char entry_four[] = "</td><td align=\"right\">";

  // size in bytes

  char entry_five[] = "</td></tr>";

  DIR *v_dir  = opendir(directory_name);

  if (v_dir == NULL) {
    return NULL;
  }

  struct dirent *entry = readdir(v_dir);

  const char *image_ext = {".gif", ".png", ".jpg", ".jpeg", ".svg"};

  while (entry != NULL) {
    if (entry->d_name[0] == '.') {
      entry = readdir(v_dir);
      continue;
    }

    struct stat file_stat = {0};
    if (stat(entry->d_name, &file_stat) == -1) {
      entry = readdir(v_dir);
      continue;
    }

    int buffer_size = 500;
    char entry_buffer[buffer_size] = "";
    int buffer_len = 0;

    memcpy(entry_buffer + buffer_len, entry_beg, strlen(entry_beg));
    buffer_len += strlen(entry_beg);

    if (S_ISDIR(file_stat.st_mode)) {
      memcpy(entry_buffer + buffer_len, "folder.gif", strlen("folder.gif"));
      buffer_len += strlen("folder.gif");
    }
    else {
      size_t len = strlen(entry->d_name);
      int is_one = 0;
      for (int i = 0; i < 5; ++i) {
        size_t ext_len = strlen(image_ext[i]);
        if (len >= ext_len && strcmp(filename + len -
              ext_len, image_ext[i]) == 0) {
          is_one = 1;
          memcpy(entry_buffer + buffer_len, "image.gif", strlen("image.gif"));
          buffer_len += strlen("image.gif");
        }
      }

      if (is_one == 0) {
        memcpy(entry_buffer + buffer_len, "text.gif", strlen("text.gif"));
        buffer_len += strlen("text.gif");
      }
    }

    memcpy(entry_buffer + buffer_len, entry_two, strlen(entry_two));
    buffer_len += strlen(entry_two);

    memcpy(entry_buffer + buffer_len, entry->d_name, strlen(entry->d_name));
    buffer_len += strlen(entry->d_name);




    entry = readdir(v_dir);
  }

  if (closedir(dir) == -1) {
    return NULL;
  }

  // end of entries

  char last_block[] = "<tr><th colspan=\"3\"><hr></th>"
    "</tr></table></body></html>";
  memcpy(page + page_itr, last_block, strlen(last_block));
  page_itr += strlen(last_block);

  page[page_itr] = '\0';

  return page;
  */

  return NULL;
} /* serve_directory() */
