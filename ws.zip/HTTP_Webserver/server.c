#include "server.h"

#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "handlers.h"
#include "http_messages.h"

char g_user_pass[MAX_USR_PWD_LEN] = "";
int *g_child_list = NULL;
int g_child_list_len = 0;

// This is a global so that it can't fail
// to be dynamically allocated.

char *g_internal_error_string =
    "HTTP/1.1 500"
    "Internal Server Error\r\nConnection: close\r\nContent"
    "-Type: text/basic\r\nContent-Length: 23\r\n\r"
    "\nAn internal error occured";

pthread_mutex_t g_pool_mutex = {0};

/*
 * Return a string in a format <user>:<password>
 */

char *return_user_pwd_string(void) {
  // note: MAX_USR_PWD_LEN is 60

  FILE *fp = NULL;
  char *line = NULL;
  size_t len = 0;

  fp = fopen("./auth.txt", "r");

  if (fp == NULL) {
    free(line);
    line = NULL;
    perror("couldn't read auth.txt");
    exit(-1);
  }

  if (getline(&line, &len, fp) == -1) {
    free(line);
    line = NULL;
    perror("couldn't read auth.txt");
    exit(-1);
  }

  sprintf(g_user_pass, "%s", line);

  free(line);
  line = NULL;
  fclose(fp);

  return g_user_pass;
} /* return_user_pwd_string() */

/*
 * Accept connections one at a time and handle them.
 */

void run_linear_server(acceptor *v_acceptor) {
  while (1) {
    socket_t *sock = accept_connection(v_acceptor);
    handle(sock);
  }
} /* run_linear_server() */

/*
 * Accept connections, creating a different child process to handle each one.
 */

void run_forking_server(acceptor *v_acceptor) {
  while (1) {
    socket_t *sock = accept_connection(v_acceptor);
    int pid = fork();

    while (pid == -1) {
      sleep(1);
      pid = fork();
    }

    if (pid == 0) {
      // in child

      handle(sock);
      exit(0);
    } else {
      ++g_child_list_len;
      g_child_list = realloc(g_child_list, sizeof(int *) * g_child_list_len);
      g_child_list[g_child_list_len - 1] = pid;
      close_socket(sock);
    }
  }
} /* run_forking_server() */

/*
 * Wrapper that satisfies the signature
 * requirements of a posix thread initializer.
 */

void *handle_thread_wrapper(void *socket) {
  handle((socket_t *)socket);

  return (void *)NULL;
} /* handle_thread_wrapper() */

/*
 * Accept connections, creating a new thread to handle each one.
 */

void run_threaded_server(acceptor *v_acceptor) {
  int ret = -1;

  while (1) {
    socket_t *sock = accept_connection(v_acceptor);
    pthread_t thread = {0};

    while (pthread_create(&thread, NULL, handle_thread_wrapper, (void *)sock)) {
      // Assume that resources will become available instead of exiting.

      sleep(1);
    }

    ret = pthread_detach(thread);

    if (ret) {
      perror("pthread_detach");
      exit(1);
    }
  }
} /* run_threaded_server() */

/*
 * a thread loop for the pooled_server
 */

void *pool_loop(void *v_acceptor) {
  while (1) {
    pthread_mutex_lock(&g_pool_mutex);

    socket_t *sock = accept_connection(v_acceptor);

    pthread_mutex_unlock(&g_pool_mutex);

    handle(sock);
  }

  return (void *)NULL;
} /* pool_loop() */

/*
 * Accept connections, drawing from a thread pool with num_threads to handle the
 * connections.
 */

void run_thread_pool_server(acceptor *v_acceptor, int num_threads) {
  // for i < num_threads spin off threads whose function is
  // to enter a while true loop that accepts connections
  // use a mutex so that only one can accept a connection
  // at a time.
  // The mutex will be shared across the threads if its a
  // global.

  pthread_mutex_init(&g_pool_mutex, NULL);

  for (int i = 0; i < num_threads; ++i) {
    pthread_t thread = {0};

    pthread_create(&thread, NULL, pool_loop, v_acceptor);

    int ret = pthread_detach(thread);

    if (ret) {
      perror("pthread_detach");
      exit(1);
    }
  }

  // now wait on the threads

  while (1) {
    sleep(1);
  }
} /* run_thread_pool_server() */

/*
 * Handle an incoming connection on the passed socket.
 */

void handle(socket_t *sock) {
  bool internal_error = false;
  http_request *request = (http_request *)malloc(sizeof(http_request));

  if (request == NULL) {
    internal_error = true;
  } else {
    request->num_headers = 0;
    request->method = NULL;
    request->request_uri = NULL;
    request->http_version = NULL;
    request->headers = NULL;
    request->message_body = NULL;
    request->query = NULL;
  }

  if (request == NULL) {
    internal_error = true;
  }

  char *request_string = NULL;

  printf("server.c: handle()\n");

  request_string = (char *) malloc((size_t)REQ_STR_LEN);

  if (request_string == NULL) {
    internal_error = true;
  }

  request_string[(int)REQ_STR_LEN - 1] = '\0';

  if (socket_read(sock, request_string, (size_t)REQ_STR_LEN) < 0) {
    perror("tls_read");
    exit(1);
  }

  printf("-----\n");
  printf("%s", request_string);
  printf("-----\n");

  int status = -1;
  if (!internal_error) {
    status = parse_request(request_string, request);
  }

  http_response *response = (http_response *)malloc(sizeof(http_response));

  if (response == NULL) {
    internal_error = true;
  }

  if (!internal_error) {
    response->status_code = status;
  }

  char *to_string = NULL;
  int len = -1;

  if (internal_error) {
    to_string = g_internal_error_string;
  } else {
    to_string = response_string(response, request, &len, sock->socket_fd);

    if (to_string == NULL) {
      internal_error = true;
      to_string = g_internal_error_string;
    }
  }

  printf("server.c: response string print:\n");
  printf("%s\n", to_string);

  if (len == -1) {
    if (strlen(to_string) != 0) {
      socket_write(sock, to_string, strlen(to_string));
    }
  } else {
    socket_write(sock, to_string, len);
  }

  // TODO: uncomment once you've added proper serving

  if (!internal_error) {
    free(to_string);
  }

  to_string = NULL;

  free(response);
  response = NULL;

  free_http_request(request);
  request = NULL;

  free(request_string);
  request_string = NULL;

  close_socket(sock);
} /* handle() */
