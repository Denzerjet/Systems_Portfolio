#ifndef SERVER_H
#define SERVER_H

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "socket.h"

#define USE_SPECIFIED (1)
#define MAX_USR_PWD_LEN (60)
#define REQ_STR_LEN (1000)

char *return_user_pwd_string(void);
void run_linear_server(acceptor *ser_acceptor);
void run_forking_server(acceptor *ser_acceptor);
void run_threaded_server(acceptor *ser_acceptor);
void run_thread_pool_server(acceptor *ser_acceptor, int num_threads);

void handle(socket_t *v_sock);

// Global variable for user and password
extern char g_user_pass[MAX_USR_PWD_LEN];
extern int *g_child_list;

#endif // SERVER_H
