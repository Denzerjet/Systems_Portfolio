#ifndef HTTP_MESSAGES_H
#define HTTP_MESSAGES_H

enum STATUS {
  OK = 200,
  BAD_REQUEST = 400,
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  NOT_FOUND = 404,
  METHOD_NOT_ALLOWED = 405,
  INTERNAL_SERVER_ERROR = 500,
  HTTP_VERSION_NOT_SUPPORTED = 505
};

const char *status_reason(int status);

typedef struct {
  char *key;
  char *value;
} header;

typedef struct {
  char *method;
  char *request_uri;
  char *http_version;
  int num_headers;
  header **headers;
  char *message_body;
  char *query;
  int status;
} http_request;

typedef struct {
  char *http_version;
  int status_code;
  char *reason_phrase;
  int num_headers;
  header **headers;
  char *message_body;
} http_response;

char *response_string(http_response *response, http_request *request, int *len,
                      int socket_fd);
int parse_request(const char *buf, http_request *request);

void print_request(http_request *request);

#endif // HTTP_MESSAGES_H
