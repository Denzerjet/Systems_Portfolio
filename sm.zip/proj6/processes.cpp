#include "processes.h"

#include <pwd.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
// include <QDebug>
#include <iostream>
using namespace std;

namespace fs = filesystem;

/*
 * Finds % cpu usage for the processes tab
 */

double getProcessCPUUsage(const string &pidStr) {
  string procStatFile = "/proc/" + pidStr + "/stat";
  ifstream statFile(procStatFile);
  if (!statFile.is_open()) {
    cerr << "Failed to open: " << procStatFile << endl;
    return 0.0;
  }

  string line;
  getline(statFile, line);
  istringstream cpuStream(line);

  string token;
  vector<string> statFields;

  while (cpuStream >> token) {
    statFields.push_back(token);
  }

  if (statFields.size() < 22) {
    cerr << "Invalid stat file format for PID: " << pidStr << endl;
    return 0.0;
  }

  long long utime = stoll(statFields[13]);
  long long stime = stoll(statFields[14]);
  long long starttime = stoll(statFields[21]);
  long long totalProcessTime = utime + stime;

  ifstream uptimeFile("/proc/uptime");
  if (!uptimeFile.is_open()) {
    cerr << "Failed to open /proc/uptime" << endl;
    return 0.0;
  }

  double systemUptime;
  uptimeFile >> systemUptime;

  // ticks / sec
  long long hertz = sysconf(_SC_CLK_TCK);
  double processUptime = systemUptime - (starttime / (double)hertz);

  if (processUptime <= 0) {
    return 0.0;
  }
  double cpuUsage = (totalProcessTime / (double)hertz) / processUptime * 100.0;
  return cpuUsage;
}

/*
 * parses thorugh processes info for each PID
 */

ProcessInfo parseProcessInfo(const string &pidStr) {
  ProcessInfo process{};
  process.pid = stoi(pidStr);
  process.parentPid = -1;
  string procDir = "/proc/" + pidStr;
  ifstream statusFile(procDir + "/status");
  if (!statusFile.is_open()) {
    cerr << "Failed to open: " << procDir + "/status" << endl;
    throw runtime_error("Cannot open status file");
  }
  string line;
  while (getline(statusFile, line)) {
    if (line.find("Name:") == 0) {
      process.name = line.substr(line.find(":") + 1);
      process.name.erase(0, process.name.find_first_not_of(" \t"));
    } else if (line.find("State:") == 0) {
      process.status = line.substr(line.find(":") + 1);
      process.status.erase(0, process.status.find_first_not_of(" \t"));
    } else if (line.find("PPid:") == 0) {
      process.parentPid = stoi(line.substr(line.find(":") + 1));
    } else if (line.find("VmRSS:") == 0) {
      process.memoryUsage = stod(line.substr(line.find(":") + 1)) / 1024.0;
    }
  }
  // debugging - remove later
  cout << "Parsed process: " << process.name << ", PID: " << process.pid
       << endl;

  // REPLACE WITH PROPER CPU USEAGE CALC !!!
  process.cpuUsage = getProcessCPUUsage(pidStr);
  return process;
} /* parseProcessInfor() */

/*
 * Function to parse and get ALL processes
 */

vector<ProcessInfo> getAllProcesses() {
  vector<ProcessInfo> processes;
  for (const auto &entry : fs::directory_iterator("/proc")) {
    string filename = entry.path().filename().string();
    if (entry.is_directory() &&
        all_of(filename.begin(), filename.end(), ::isdigit)) {
      try {
        // remove debugging later
        cout << "Found process directory: " << filename << endl;
        processes.push_back(parseProcessInfo(filename));
      } catch (const exception &e) {
        cerr << "Error parsing process: " << filename << " - " << e.what()
             << endl;
        continue;
      }
    }
  }
  cout << "Number of processes parsed: " << processes.size() << endl;
  return processes;
} /* getAllProcesses() */

/*
 * Function to parse and get only ACTIVE processes
 */

vector<ProcessInfo> getActiveProcesses() {
  vector<ProcessInfo> allProcesses = getAllProcesses();
  vector<ProcessInfo> activeProcesses;
  for (const auto &process : allProcesses) {
    if (process.cpuUsage > 0.0) {
      activeProcesses.push_back(process);
    }
  }
  return activeProcesses;
} /* getActiveProcesses() */

/*
 * Function to get only MY processes
 */

vector<ProcessInfo> getUserProcesses(uid_t uid) {
  vector<ProcessInfo> allProcesses = getAllProcesses();
  vector<ProcessInfo> userProcesses;
  struct passwd *pw = getpwuid(uid);
  if (!pw) {
    return userProcesses;
  }

  string userName = pw->pw_name;

  for (const auto &process : allProcesses) {
    ifstream statusFile("/proc/" + to_string(process.pid) + "/status");
    string line;
    while (getline(statusFile, line)) {
      if (line.find("Uid:") == 0) {
        istringstream uidStream(line.substr(line.find(":") + 1));
        int fileUid;
        uidStream >> fileUid;
        if (fileUid == uid) {
          userProcesses.push_back(process);
        }
        break;
      }
    }
  }
  return userProcesses;
} /* getUserProcesses() */
