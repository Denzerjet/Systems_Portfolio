#ifndef FILESYS_H
#define FILESYS_H

#include <string>
#include <vector>

struct cFileSystemInfo {
  std::string device;
  std::string type;
  std::string size;
  std::string used;
  std::string avail;
  float use_perc;    // Stored as a float for bar graph usage
  std::string free;  // size - used
  std::string directory;
};

std::vector<cFileSystemInfo> getFileSysInfo();
float freeDifUnitCalc(float size, float used, std::string sizeUnit,
                      std::string usedUnit);
double convertToBase(float value, const std::string& unit);

#endif  // FILESYS_H
