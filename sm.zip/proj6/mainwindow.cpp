
#include "mainwindow.h"

#include <memory.h>
#include <pwd.h>
#include <signal.h>
#include <unistd.h>

#include <QAction>
#include <QActionGroup>
#include <QDebug>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QHeaderView>
#include <QMenu>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTextStream>
#include <QTimer>
#include <QVBoxLayout>
#include <QtCharts/QCategoryAxis>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <unordered_map>

#include "./ui_mainwindow.h"
#include "fileSys.h"
#include "processes.h"
#include "sysInfo.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);

  SetUpBasicSystemInformation();
  SetUpFileSystemInfo();

  SetUpViewTab();
  connect(ui->Tabs, &QTabWidget::currentChanged, this, &MainWindow::tabDisplay);

  SetUpGraphPreliminaries();

  SetUpCPUGraph();
  SetUpMemoryGraph();
  SetUpNetworkGraph();
  seconds_timer->start(1000);

  /*
  // will auto refresh the processes every 5 seconds in addition to refresh
  button QTimer *processUpdateTimer = new QTimer(this);
  connect(processUpdateTimer, &QTimer::timeout, this,
  &MainWindow::updateProcesses); processUpdateTimer->start(5000);
  */

  connect(ui->processTree, &QTreeWidget::itemDoubleClicked, this,
          [this](QTreeWidgetItem *item, int column) {
            int pid = item->text(3).toInt();
            showProcessActions(pid);
          });

  connect(this, &MainWindow::processStopped, this, [this](int pid) {
    QMessageBox::information(
        this, "Process Stopped",
        QString("Process with PID %1 has been stopped.").arg(pid));
    refreshProcesses();
  });

  connect(this, &MainWindow::processStopFailed, this,
          [this](int pid, const QString &error) {
            QMessageBox::critical(
                this, "Failed to Stop Process",
                QString("Failed to stop process with PID %1. Error: %2")
                    .arg(pid)
                    .arg(error));
          });
}

MainWindow::~MainWindow() {
  qDebug() << cpu_chart_view->parent();
  // this->dumpObjectTree();
  GraphCleanUp();
  delete ui;
  // this->dumpObjectTree();
}

// std::unique_ptr<char[]> get_os_version() {
//     std::string os_v_str = "os version placeholder";
//     std::unique_ptr<char[]> smart_os_v(new char[strlen(os_v_str.c_str()) +
//     1]); strncpy(smart_os_v.get(), os_v_str.c_str(),
//     strlen(os_v_str.c_str())); return smart_os_v;
// }

void MainWindow::SetUpBasicSystemInformation() {
  // os version label
  // std::unique_ptr<char[]> smart_os_v = get_os_version();
  // QString os_version_qstr = QString::fromStdString(smart_os_v.get());
  // ui->os_version_label->setText(os_version_qstr);

  // os
  std::string os_version = "OS: " + getOSReleaseVersion();
  QString osv_qstring = QString::fromStdString(os_version);
  ui->os_version_label->setText(osv_qstring);

  // kernel
  std::string kernel_version = "Kernel: " + getKernelVersion();
  QString kernel_qstring = QString::fromStdString(kernel_version);
  ui->kernel_version_label->setText(kernel_qstring);

  // cpu
  std::string cpu_model = "Processor: " + findCPUModelName();
  QString cpu_qstring = QString::fromStdString(cpu_model);
  ui->cpu_label->setText(cpu_qstring);

  std::string total_ram = "Memory: " + std::to_string(memInfo()) + " GiB";
  QString ram_qstring = QString::fromStdString(total_ram);
  ui->memory_label->setText(ram_qstring);

  std::string total_storage =
      "Available disk space: " + std::to_string(diskSpaceInfo()) + " GiB";
  QString storage_qstring = QString::fromStdString(total_storage);
  ui->disk_space_label->setText(storage_qstring);
} /* SetUpBasicSystemInformation() */

/*
 * set up top right corner button that allows you to
 * select from all, active, my processes or refresh
 */

void MainWindow::SetUpViewTab() {
  QActionGroup *viewGroup = new QActionGroup(this);
  viewGroup->setExclusive(true);  // Ensure mutual exclusivity

  // active
  ui->actionActiveProcesses->setCheckable(true);
  ui->actionActiveProcesses->setActionGroup(viewGroup);

  // all
  ui->actionAllProcesses->setCheckable(true);
  ui->actionAllProcesses->setActionGroup(viewGroup);

  // my
  ui->actionMyProcesses->setCheckable(true);
  ui->actionMyProcesses->setActionGroup(viewGroup);

  ui->actionAllProcesses->setChecked(true);

  connect(ui->actionActiveProcesses, &QAction::triggered, this,
          &MainWindow::setActiveProcesses);
  connect(ui->actionAllProcesses, &QAction::triggered, this,
          &MainWindow::setAllProcesses);
  connect(ui->actionMyProcesses, &QAction::triggered, this,
          &MainWindow::setMyProcesses);
  connect(ui->actionRefresh, &QAction::triggered, this,
          &MainWindow::refreshProcesses);
} /* SetUpViewTab() */

/*
 * makes view tab only visible on processes page
 */

void MainWindow::tabDisplay(int index) {
  if (ui->Tabs->widget(index)->objectName() == "Processes_Tab") {
    ui->menuView->menuAction()->setVisible(true);
    // make it default to all
    if (ui->actionAllProcesses->isChecked()) {
      setAllProcesses();
    } else {
      ui->actionAllProcesses->setChecked(true);
      setAllProcesses();
    }
  } else {
    ui->menuView->menuAction()->setVisible(false);
  }
} /* tabDisplay() */

/*
 * update the process whenever the diff view options are selected
 * and configure tree stuff
 */

void MainWindow::updateProcesses() {
  ui->processTree->clear();
  // delete debugging statements later
  std::vector<ProcessInfo> processes;
  if (ui->actionActiveProcesses->isChecked()) {
    processes = getActiveProcesses();
    qDebug() << "Active processes selected.";
  } else if (ui->actionMyProcesses->isChecked()) {
    processes = getUserProcesses(getuid());
    qDebug() << "My processes selected.";
  } else {
    processes = getAllProcesses();
    qDebug() << "All processes selected.";
  }
  QMap<int, QTreeWidgetItem *> pidToItemMap;
  // add in somesort of drop down widget to display children in acc tree struct
  // - todo
  for (const auto &process : processes) {
    if (process.name.empty()) {
      qDebug() << "Skipping process with empty name. PID:" << process.pid;
      continue;
    }
    QTreeWidgetItem *item = new QTreeWidgetItem();
    item->setText(0, QString::fromStdString(process.name));
    item->setText(1, QString::fromStdString(process.status));
    item->setText(2, QString::number(process.cpuUsage, 'f', 2) + " %");
    item->setText(3, QString::number(process.pid));
    item->setText(4, QString::number(process.memoryUsage, 'f', 2) + " MB");
    pidToItemMap[process.pid] = item;
    qDebug() << "Added process to map:" << QString::fromStdString(process.name)
             << "PID:" << process.pid;
  }
  // connect parent child
  for (const auto &process : processes) {
    if (process.parentPid != -1 && pidToItemMap.count(process.parentPid)) {
      pidToItemMap[process.parentPid]->addChild(pidToItemMap[process.pid]);
    } else {
      ui->processTree->addTopLevelItem(pidToItemMap[process.pid]);
    }
  }

  // change to expandAll if we want the trees to be default expanded
  ui->processTree->collapseAll();

} /* updateProcesses() */

/*
 * sets the active processes when called upon
 */

void MainWindow::setActiveProcesses() {
  updateProcesses();
  // placeholder - check gui
} /* setActiveProcesses() */

/*
 * sets all processes when called upon
 */

void MainWindow::setAllProcesses() {
  updateProcesses();
  // placeholder - check gui
} /* setAllProcesses() */

/*
 * sets the user specific processes when called upon
 */

void MainWindow::setMyProcesses() {
  updateProcesses();
  // placeholder - check gui
} /* setMyProcesses() */

/*
 * calls on update when refresh button is hit
 */

void MainWindow::refreshProcesses() {
  updateProcesses();
  // placeholder - check gui
} /* refreshProcesses() */

/*
 * Creates a graph to hold the cpu usage plotted points
 */

void MainWindow::SetUpCPUGraph() {
  if (!cpu_graph) {
    cpu_graph = new QtCharts::QChart();
    cpu_graph->setTitle("CPU History");

    for (int i = 0; i < num_cpus; ++i) {
      cpu_graph->addSeries(cpu_serieses[i]);
    }

    cpu_graph->createDefaultAxes();
    cpu_graph->axisX()->setLabelsVisible(false);
    cpu_graph->axisY()->setRange(0, 100);

    cpu_chart_view = new QtCharts::QChartView(cpu_graph, this);
    cpu_chart_view->setRenderHint(QPainter::Antialiasing);
    // chartView->resize(400, 300);
    cpu_chart_view->show();

    QLayout *layout = ui->cpu_graph_widget->layout();
    if (!layout) {
      layout = new QVBoxLayout(ui->cpu_graph_widget);
      ui->cpu_graph_widget->setLayout(layout);
    }
    layout->addWidget(cpu_chart_view);
  }

  cpu_graph->axisX()->setRange(cpu_x - max_graph_points, cpu_x);

  QObject::connect(seconds_timer, &QTimer::timeout, this, [this]() {
    // std::string cpu_name =
    // ui->cpu_select_widget->currentText().toStdString(); int usage =
    // cpu_usage(cpu_name);

    std::vector<int> cpu_usages = cpu_stats();

    for (int i = 0; i < num_cpus; ++i) {
      // printf("cpu %d usage: %d\n", i, cpu_usages[i]);
      cpu_serieses[i]->append(cpu_x, cpu_usages[i]);

      if (cpu_serieses[i]->count() > max_graph_points) {
        cpu_serieses[i]->remove(0);
      }
    }

    // series->append(x, usage);
    cpu_x++;

    cpu_graph->axisX()->setRange(cpu_x - max_graph_points, cpu_x);
    cpu_graph->axisY()->setRange(0, 100);

    cpu_graph->update();
  });
} /* SetUpCPUGraph() */

/*
 * clears the displayed cpu graph
 */

void MainWindow::ClearGraph() {
  int num_old_pts = series->count();

  for (int i = 0; i < num_old_pts; ++i) {
    series->remove(0);
  }
} /* ClearGraph() */

/*
 * Graph for RAM and Swap usage
 */

void MainWindow::SetUpMemoryGraph() {
  QtCharts::QChart *chart = new QtCharts::QChart();
  QtCharts::QLineSeries *mem_series = new QtCharts::QLineSeries(this);
  QtCharts::QLineSeries *swap_series = new QtCharts::QLineSeries(this);
  chart->addSeries(mem_series);
  chart->addSeries(swap_series);
  chart->createDefaultAxes();
  chart->setTitle("RAM and Swap");

  QtCharts::QChartView *chartView = new QtCharts::QChartView(chart, this);
  chartView->setRenderHint(QPainter::Antialiasing);
  chartView->resize(400, 300);
  chart->axisX()->setLabelsVisible(false);
  static int x = 0;
  static int max_points = 60;
  chart->axisY()->setRange(0, 100);
  chart->axisX()->setRange(x - max_points, x);
  chartView->show();

  QTimer *timer = new QTimer(this);
  QObject::connect(timer, &QTimer::timeout, this,
                   [this, chart, mem_series, swap_series]() {
                     int mem_usage = MemoryUsage();
                     int swap_usage = SwapUsage();

                     mem_series->append(x, mem_usage);
                     swap_series->append(x, swap_usage);
                     x++;

                     chart->axisX()->setRange(x - max_points, x);
                     chart->axisY()->setRange(0, 100);

                     chart->update();
                     if (mem_series->count() > max_points) {
                       mem_series->remove(0);
                     }
                     if (swap_series->count() > max_points) {
                       swap_series->remove(0);
                     }
                   });
  timer->start(1000);

  // QVBoxLayout *layout = ui->cpu_graph_widget->layout();
  QLayout *layout = ui->memory_usage_widget->layout();

  if (layout == nullptr) {
    layout = new QVBoxLayout(ui->memory_usage_widget);
  }

  layout->addWidget(chartView);
} /* SetUpMemoryGraph() */

/*
 * Graph for network usage, sending
 * and receiving
 */

void MainWindow::SetUpNetworkGraph() {
  QtCharts::QChart *chart = new QtCharts::QChart();
  QtCharts::QLineSeries *recv_series = new QtCharts::QLineSeries(this);
  QtCharts::QLineSeries *send_series = new QtCharts::QLineSeries(this);
  chart->addSeries(recv_series);
  chart->addSeries(send_series);
  chart->createDefaultAxes();
  chart->setTitle("Receiving and Sending in GiB/s");

  QtCharts::QChartView *chartView = new QtCharts::QChartView(chart, this);
  chartView->setRenderHint(QPainter::Antialiasing);
  chartView->resize(400, 300);
  chart->axisX()->setLabelsVisible(false);
  static int x = 0;
  static int max_points = 60;
  static int highest_num = 100;
  chart->axisY()->setRange(0, 100);
  chart->axisX()->setRange(x - max_points, x);
  chartView->show();

  QTimer *timer = new QTimer(this);
  QObject::connect(timer, &QTimer::timeout, this,
                   [this, chart, recv_series, send_series]() {
                     std::vector network_usage = NetworkUsage();

                     // printf("recv, send: %d %d\n", network_usage[0],
                     // network_usage[1]);

                     if (network_usage[0] > highest_num) {
                       highest_num = network_usage[0];
                     }

                     if (network_usage[1] > highest_num) {
                       highest_num = network_usage[1];
                     }

                     recv_series->append(x, network_usage[0]);
                     send_series->append(x, network_usage[1]);
                     x++;

                     chart->axisX()->setRange(x - max_points, x);
                     chart->axisY()->setRange(0, highest_num);

                     chart->update();
                     if (recv_series->count() > max_points) {
                       recv_series->remove(0);
                     }
                     if (send_series->count() > max_points) {
                       send_series->remove(0);
                     }
                   });
  timer->start(1000);

  // QVBoxLayout *layout = ui->cpu_graph_widget->layout();
  QLayout *layout = ui->network_history_widget->layout();

  if (layout == nullptr) {
    layout = new QVBoxLayout(ui->network_history_widget);
  }

  layout->addWidget(chartView);
}

// starting process specific action stuff

void MainWindow::showProcessActions(int pid) {
  QMenu menu(this);
  menu.addAction("Stop Process", this, [this, pid]() { stopProcess(pid); });
  menu.addAction("Continue Process", this,
                 [this, pid]() { continueProcess(pid); });
  menu.addAction("Kill Process", this, [this, pid]() { killProcess(pid); });
  menu.addAction("List Memory Maps", this,
                 [this, pid]() { showMemoryMaps(pid); });
  menu.addAction("List Open Files", this,
                 [this, pid]() { showOpenFiles(pid); });
  menu.addAction("Show Detailed View", this,
                 [this, pid]() { showProcessDetails(pid); });
  menu.exec(QCursor::pos());
}

QString MainWindow::getProcessName(int pid) {
  QString processName = "Unknown";
  QString statusFilePath = QString("/proc/%1/status").arg(pid);
  QFile statusFile(statusFilePath);
  if (statusFile.open(QIODevice::ReadOnly)) {
    QTextStream in(&statusFile);
    while (!in.atEnd()) {
      QString line = in.readLine();
      if (line.startsWith("Name:")) {
        processName = line.split(":")[1].trimmed();
        break;
      }
    }
  } else {
    qDebug() << "Failed to open status file for PID:" << pid;
  }

  return processName;
}

/*
 * Stop the process
 */

void MainWindow::stopProcess(int pid) {
  if (pid <= 1) {
    QMessageBox::warning(this, "Warning",
                         "Cannot stop important system processes (PID <= 1).");
    return;
  }
  QString processName = getProcessName(pid);
  qDebug() << "Attempting to stop process with PID:" << pid;
  if (kill(pid, SIGSTOP) == 0) {
    qDebug() << "Process stopped successfully.";
    QMessageBox::information(this, "Process Stopped",
                             QString("Process '%1' (PID %2) has been stopped.")
                                 .arg(processName)
                                 .arg(pid));
  } else {
    qDebug() << "Failed to stop process. Error:" << strerror(errno);
    QMessageBox::critical(
        this, "Error",
        QString("Failed to stop process '%1' (PID %2). Error: %3")
            .arg(processName)
            .arg(pid)
            .arg(strerror(errno)));
  }
}

/*
 * Continue the process
 */
void MainWindow::continueProcess(int pid) {
  if (kill(pid, SIGCONT) == 0) {
    QMessageBox::information(this, "Success",
                             "Process continued successfully.");
  } else {
    QMessageBox::critical(this, "Error", "Failed to continue process.");
  }
}

/*
 * Kill the process
 */

void MainWindow::killProcess(int pid) {
  if (kill(pid, SIGKILL) == 0) {
    QMessageBox::information(this, "Success", "Process killed successfully.");
    refreshProcesses();
  } else {
    QMessageBox::critical(this, "Error", "Failed to kill the process.");
  }
}

/*
 * Show all the memory maps
 */

void MainWindow::showMemoryMaps(int pid) {
  // Open the /proc/[pid]/maps file
  QString mapsFilePath = QString("/proc/%1/maps").arg(pid);
  QFile mapsFile(mapsFilePath);
  if (!mapsFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
    QMessageBox::critical(
        this, "Error",
        QString("Could not open memory maps for process %1.").arg(pid));
    qDebug() << "Failed to open file:" << mapsFilePath;
    return;
  }

  QByteArray fileContent = mapsFile.readAll();
  qDebug() << "File content size:" << fileContent.size();
  qDebug() << "File content preview:" << QString(fileContent).left(500);
  QDialog *dialog = new QDialog(this);
  dialog->setWindowTitle(QString("Memory maps for process (PID: %1)").arg(pid));
  dialog->resize(800, 400);
  QTableWidget *table = new QTableWidget(dialog);
  table->setColumnCount(10);
  table->setHorizontalHeaderLabels(
      {"Filename", "VM Start", "VM End", "VM Size (KiB)", "Flags", "VM Offset",
       "Private Clean", "Private Dirty", "Shared Clean", "Shared Dirty"});

  QVBoxLayout *layout = new QVBoxLayout(dialog);
  layout->addWidget(table);
  int row = 0;

  QString contentAsString(fileContent);
  QStringList lines = contentAsString.split('\n');

  for (const QString &line : lines) {
    if (line.isEmpty()) continue;
    QStringList parts = line.split(QRegExp("\\s+"));
    if (parts.size() < 6) continue;
    QString vmRange = parts[0];
    QStringList rangeParts = vmRange.split('-');
    if (rangeParts.size() < 2) continue;

    QString vmStart = rangeParts[0];
    QString vmEnd = rangeParts[1];
    QString flags = parts[1];
    QString vmOffset = parts[2];
    QString dev = parts[3];
    QString inode = parts[4];
    QString filename =
        (parts.size() > 5) ? parts.mid(5).join(" ") : "[anonymous]";
    bool ok;
    qint64 startAddr = vmStart.toLongLong(&ok, 16);
    qint64 endAddr = vmEnd.toLongLong(&ok, 16);
    QString vmSize =
        ok ? QString::number((endAddr - startAddr) / 1024) + " KiB" : "Unknown";
    // replace belwo with acc values

    QString privateClean = "0 bytes";
    QString privateDirty = "0 bytes";
    QString sharedClean = "0 bytes";
    QString sharedDirty = "0 bytes";
    table->insertRow(row);
    table->setItem(row, 0, new QTableWidgetItem(filename));
    table->setItem(row, 1, new QTableWidgetItem(vmStart));
    table->setItem(row, 2, new QTableWidgetItem(vmEnd));
    table->setItem(row, 3, new QTableWidgetItem(vmSize));
    table->setItem(row, 4, new QTableWidgetItem(flags));
    table->setItem(row, 5, new QTableWidgetItem(vmOffset));
    table->setItem(row, 6, new QTableWidgetItem(privateClean));
    table->setItem(row, 7, new QTableWidgetItem(privateDirty));
    table->setItem(row, 8, new QTableWidgetItem(sharedClean));
    table->setItem(row, 9, new QTableWidgetItem(sharedDirty));
    row++;
  }

  table->resizeColumnsToContents();

  mapsFile.close();

  dialog->setLayout(layout);
  dialog->exec();
} /* showMemoryMaps() */

void MainWindow::showOpenFiles(int pid) {
  QString fdDirPath = QString("/proc/%1/fd").arg(pid);
  QDir fdDir(fdDirPath);
  if (!fdDir.exists()) {
    QMessageBox::critical(
        this, "Error",
        QString("Could not access open files for process (PID: %1).").arg(pid));
    return;
  }

  QDialog *dialog = new QDialog(this);
  dialog->setWindowTitle(QString("Files opened by process (PID: %1)").arg(pid));
  dialog->resize(600, 400);

  QTableWidget *table = new QTableWidget(dialog);
  table->setColumnCount(3);
  table->setHorizontalHeaderLabels({"FD", "Type", "Object"});
  table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
  QVBoxLayout *layout = new QVBoxLayout(dialog);
  layout->addWidget(table);

  QFileInfoList fileDescriptors =
      fdDir.entryInfoList(QDir::NoDotAndDotDot | QDir::Files);
  int row = 0;
  for (const QFileInfo &fdInfo : fileDescriptors) {
    QString fd = fdInfo.fileName();
    QString target = fdInfo.symLinkTarget();
    QString type;
    if (target.startsWith("/dev")) {
      type = "file";
    } else if (target.contains("socket")) {
      type = "local socket";
    } else if (target.contains("anon_inode")) {
      type = "anonymous inode";
    } else if (target.isEmpty()) {
      type = "unknown";
    } else {
      type = "file";
    }
    table->insertRow(row);
    table->setItem(row, 0, new QTableWidgetItem(fd));
    table->setItem(row, 1, new QTableWidgetItem(type));
    table->setItem(row, 2, new QTableWidgetItem(target));
    row++;
  }

  dialog->setLayout(layout);
  dialog->exec();
} /* showOpenFiles() */

/*
 * Sets up variables used by the graphs
 */

void MainWindow::SetUpGraphPreliminaries() {
  seconds_timer = new QTimer(this);
  cpu_graph = nullptr;
  num_cpus = NumCPUs();
  cpu_x = 0;
  cpu_serieses = std::vector<QtCharts::QLineSeries *>(num_cpus);
  max_graph_points = 60;

  for (int i = 0; i < num_cpus; ++i) {
    cpu_serieses[i] = new QtCharts::QLineSeries(this);
  }
} /* SetUpGraphPreliminaries() */

/*
 * deletes dynamically allocated variables
 */

void MainWindow::GraphCleanUp() {
  // if (cpu_chart_view) {
  // delete cpu_chart_view;
  // cpu_chart_view = nullptr;
  //}

  if (cpu_graph) {
    delete cpu_graph;
    cpu_graph = nullptr;
  }

  // for (auto series : cpu_serieses) {
  //     series->clear();  // If dynamically allocated, ensure proper deletion
  // }

  cpu_serieses.clear();

  if (seconds_timer) {
    seconds_timer->stop();
    delete seconds_timer;
    seconds_timer = nullptr;
  }
}

void MainWindow::showProcessDetails(int pid) {
  QDialog *dialog = new QDialog(this);
  dialog->setWindowTitle(QString("Process Properties (PID: %1)").arg(pid));
  dialog->resize(600, 400);
  QGridLayout *gridLayout = new QGridLayout(dialog);

  int row = 0;

  // username
  gridLayout->addWidget(new QLabel("User:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::fromStdString(GetProcessUser(pid))),
                        row++, 1);

  // status
  gridLayout->addWidget(new QLabel("Status:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetProcessStatus(pid))), row++, 1);

  // mem usage - same as resident
  gridLayout->addWidget(new QLabel("Memory:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetResidentMemorySize(pid))), row++, 1);

  // virtual mem
  gridLayout->addWidget(new QLabel("Virtual Memory:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetVirtualMemorySize(pid))), row++, 1);

  // resident mem
  gridLayout->addWidget(new QLabel("Resident Memory:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetResidentMemorySize(pid))), row++, 1);

  // writable mem
  gridLayout->addWidget(new QLabel("Writable Memory:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetWritableMemory(pid))), row++, 1);

  // shared mem
  gridLayout->addWidget(new QLabel("Shared Memory:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetSharedMemorySize(pid))), row++, 1);

  // x server mem
  gridLayout->addWidget(new QLabel("X Server Memory:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::fromStdString(GetXServerMem(pid))),
                        row++, 1);

  // %cpu
  gridLayout->addWidget(new QLabel("CPU:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString("%1%").arg(getProcessCPUUsage(std::to_string(pid)))),
      row++, 1);

  // cpu time
  gridLayout->addWidget(new QLabel("CPU Time:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::fromStdString(GetCPUTime(pid))),
                        row++, 1);

  // time started
  gridLayout->addWidget(new QLabel("Started:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetProcessStartTime(pid))), row++, 1);

  // nice
  gridLayout->addWidget(new QLabel("Nice:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::number(GetProcessNiceValue(pid))),
                        row++, 1);

  // priority
  gridLayout->addWidget(new QLabel("Priority:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::number(GetProcessPriority(pid))),
                        row++, 1);

  // ID
  gridLayout->addWidget(new QLabel("ID:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::number(pid)), row++, 1);

  // Security Context
  gridLayout->addWidget(new QLabel("Security Context:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetProcessSecurityContext(pid))), row++,
      1);

  // cmd line
  gridLayout->addWidget(new QLabel("Command Line:"), row, 0);
  gridLayout->addWidget(new QLabel(QString::fromStdString(GetCommandLine(pid))),
                        row++, 1);

  // waiting channel
  gridLayout->addWidget(new QLabel("Waiting Channel:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetWaitingChannel(pid))), row++, 1);

  // control group
  gridLayout->addWidget(new QLabel("Control Group:"), row, 0);
  gridLayout->addWidget(
      new QLabel(QString::fromStdString(GetControlGroup(pid))), row++, 1);

  QPushButton *closeButton = new QPushButton("Close", dialog);
  connect(closeButton, &QPushButton::clicked, dialog, &QDialog::accept);
  gridLayout->addWidget(closeButton, row, 0, 1, 2);
  dialog->setLayout(gridLayout);
  dialog->exec();
}

void MainWindow::SetUpFileSystemInfo() {
  // Clear existing rows
  ui->fileSysTable->clearContents();
  ui->fileSysTable->setRowCount(0);

  // Retrieve file system information
  std::vector<cFileSystemInfo> fileSystems = getFileSysInfo();

  // Set column headers
  ui->fileSysTable->setColumnCount(8);
  QStringList headers = {"Device", "Directory", "Type", "Total",
                         "Free",   "Available", "Used", "Use %"};
  ui->fileSysTable->setHorizontalHeaderLabels(headers);

  // Helper function to create a non-editable QTableWidgetItem
  auto createNonEditableItem = [](const QString &text) -> QTableWidgetItem * {
    QTableWidgetItem *item = new QTableWidgetItem(text);
    item->setFlags(item->flags() &
                   ~Qt::ItemIsEditable);  // Remove editable flag
    return item;
  };

  // Helper function to append "iB" to a value if it's not "0"
  auto appendIB = [](const std::string &value) -> QString {
    return (value != "0") ? QString::fromStdString(value) + "iB"
                          : QString::fromStdString(value);
  };

  // Populate table with data
  for (size_t i = 0; i < fileSystems.size(); ++i) {
    const cFileSystemInfo &fs = fileSystems[i];
    ui->fileSysTable->insertRow(i);

    ui->fileSysTable->setItem(
        i, 0, createNonEditableItem(QString::fromStdString(fs.device)));
    ui->fileSysTable->setItem(
        i, 1, new QTableWidgetItem(QString::fromStdString(fs.directory)));
    ui->fileSysTable->setItem(
        i, 2, createNonEditableItem(QString::fromStdString(fs.type)));
    ui->fileSysTable->setItem(i, 3, createNonEditableItem(appendIB(fs.size)));
    ui->fileSysTable->setItem(i, 4, createNonEditableItem(appendIB(fs.free)));
    ui->fileSysTable->setItem(i, 5, createNonEditableItem(appendIB(fs.avail)));
    ui->fileSysTable->setItem(i, 6, createNonEditableItem(appendIB(fs.used)));

    // Set up the progress bar for "Use %"
    int usePercent = static_cast<int>(fs.use_perc);
    QProgressBar *progressBar = new QProgressBar();
    progressBar->setRange(0, 100);
    progressBar->setValue(usePercent);
    progressBar->setTextVisible(
        false);  // Hide the text inside the progress bar

    // Create a widget item for the "Use %" column and set the progress bar as
    // its widget
    ui->fileSysTable->setCellWidget(i, 7, progressBar);
  }
}
