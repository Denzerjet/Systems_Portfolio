#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
  Q_OBJECT

 public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

 private slots:
  void setActiveProcesses();
  void setAllProcesses();
  void setMyProcesses();
  void refreshProcesses();
  void tabDisplay(int index);
  void ClearGraph();
  void stopProcess(int pid);
  void continueProcess(int pid);
  void killProcess(int pid);
  void showMemoryMaps(int pid);
  void showOpenFiles(int pid);

 private:
  Ui::MainWindow *ui;
  QtCharts::QLineSeries *series;
  std::vector<QtCharts::QLineSeries *> cpu_serieses;
  QtCharts::QChart *cpu_graph;
  int num_cpus;
  int cpu_x;
  int max_graph_points;
  QtCharts::QChartView *cpu_chart_view;
  QTimer *seconds_timer;

  void SetUpGraphPreliminaries();
  void GraphCleanUp();
  void SetUpViewTab();
  void updateProcesses();
  void SetUpBasicSystemInformation();
  void SetUpCPUGraph();
  void SetUpMemoryGraph();
  void SetUpNetworkGraph();
  void showProcessActions(int pid);
  QString getProcessName(int pid);
  void showProcessDetails(int pid);
  void SetUpFileSystemInfo();

 signals:
  void processStopped(int pid);  // Signal for successful process stop
  void processStopFailed(int pid, const QString &error);
};

#endif  // MAINWINDOW_H
