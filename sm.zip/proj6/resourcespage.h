// #ifndef RESOURCESPAGE_H
// #define RESOURCESPAGE_H

// #include <QMainWindow>

// void addCPULabels(Ui::MainWindow *ui);

// #endif // RESOURCESPAGE_H

// #include <QMainWindow>

// QT_BEGIN_NAMESPACE
// namespace Ui {
// class ResourcesPage;
// }
// QT_END_NAMESPACE

// class ResourcesPage : public QWidget
// {
//     Q_OBJECT
// public:
//     explicit ResourcesPage(QWidget* parent = nullptr);
//     void SetUpTestGraph();
// private:
//     Ui::ResourcesPage* ui;
// };
