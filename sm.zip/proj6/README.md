# proj6
Nathan Crocker
Kian Nowrouzi
Ashrita Gollapalli

**How to Run System Monitor**
- Run the following commands
- cd ./build
- make
- system_monitor

Directions for build (adds considerable data to the repo so do not commit the created directory)
run the following commands
- mkdir build
- cd ./build
- cmake ..
- make

and then if there was no errors in the code there should be an executable in 'build' called ./system\_monitor

**Process Information:**
- In processes tab to expand tree structure to view child processes select the triangle next to the parent process
- Select the view button in the top left corner to navigate to "All Processes", "My Processes", "Active Processes", and the "Refresh" button
- The process list will only update when the "Refresh" button is hit
- To  stop, continue, kill, list memory maps, list open files, or view process details - double click on the process you want to view this information for and a menu will pop up

**Resource Information:**
- The order of plots in titles matches the order of the colors of the plots (ex: RAM and Swap corresponds to the blue and green plots respectively)
- CPU history is in terms of % from 0-100, same for the Memory and Swap History
- Network history has a variable axis that uses a tracked max value for the range of the y axis. The amount being received is so large that it will look like the two plots are straight lines, this is not true. The scale is so large and there is no way to reliable create a range that would include all potential points without having them be dynamic, so the small changes in these plots will appear as very subtle zig zags. This is also true with the Memory and Swap History graph (not in the dynamic axis but in that the changes are so small relative to the axis that they will just be very small zig zaps)
- For the CPUs there is only a purple line visible, this is because the cpu perecentages are all similar. At the time of testing they were all within 2-3% and so the purple plot is just covering all of the others.

**File Descriptor leak:**
- There is an open file descriptor 5 at exit according to valgrind, however the source of this leak is not within our control to handle as it is used internally by Qt.
- "at 0x60C3CDB: eventfd (syscall-template.S:120)" at the highest level and " by 0x60C3A03: clone (clone.S:100)" at the lowest level. At a middle level of the call stack we see "by 0x5B048DC: QEventDispatcherGlibPrivate::QEventDispatcherGlibPrivate(_GMainContext*) (in /usr/lib/x86_64-linux-gnu/libQt5Core.so.5.15.3)" showing that this is a Qt internal fd.

**Memory Leak**
- There is a significant amount of memory that is still reachable at exit. This is due to Qt not deallocating memory for objects upon exit. The user does not have direct access to such members as the "QFontDatabase::findFont(QFontDef const&, int)" which result in the leaked memory. We theorize that this is due to Qt not freeing the memory if it knows that the program will exit and cause the resources to be reclaimable by the OS. When we run our program for prolonged periods of time we see no sign of running out of memory, indicating that Qt is internally reclaiming the resources as the program runs and simply does not clean up fully at exit.
- This is further supported by the leaks not matching any file that we created or worked on, such as "_dl_new_object" or "_dl_open" when we do not make such calls. https://edstem.org/us/courses/62297/discussion/5807700?comment=13459866
- There is an edstem where a student had researched online and found that this is common for Qt, in addition when we call "this->dumpObjectTree();" on the MainWindow's destructor (which is the root QObject of our project) we see that all of the components we use are children of this root object, and so Qt has control over the resources at runtime and will prevent a memory maximum being hit on its own.
