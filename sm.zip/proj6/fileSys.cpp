#include "fileSys.h"

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <cmath>
#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

/* Here's what the FileSystemInfo struct looks like for easy reference
   Note that storage strings contain value and unit prefix
   ie: 4.7T for 4.7TiB

struct FileSystemInfo {
  std::string device;
  std::string type;
  std::string size; // Total storage
  std::string used;
  std::string avail;
  float use_perc;  // Stored as a float for bar graph usage
  std::string free; // size - used
  std::string directory;
};
*/

/*
 * returns the file system information as a vector of "FileSystemInfo" structs
 */

vector<cFileSystemInfo> getFileSysInfo() {
  vector<cFileSystemInfo> fileSystems;
  int pipefd[2];
  pid_t pid;
  char buffer[1024];
  string output;

  if (pipe(pipefd) == -1) {
    perror("pipe");
    return fileSystems;
  }

  pid = fork();
  if (pid == -1) {
    perror("fork");
    return fileSystems;
  } else if (pid == 0) {
    // child
    close(pipefd[0]);
    dup2(pipefd[1], STDOUT_FILENO);
    close(pipefd[1]);

    execl("/bin/sh", "sh", "-c", "df -hT --si", (char*)nullptr);
    perror("execl");
    _exit(1);
  } else {
    // parent
    close(pipefd[1]);
    ssize_t bytesRead;
    while ((bytesRead = read(pipefd[0], buffer, sizeof(buffer) - 1)) > 0) {
      buffer[bytesRead] = '\0';
      output += buffer;
    }
    close(pipefd[0]);

    waitpid(pid, nullptr, 0);

    istringstream iss(output);
    string line;
    bool firstLine = true;

    while (getline(iss, line)) {
      if (firstLine) {
        firstLine = false;
        continue;
      }

      istringstream lineStream(line);
      cFileSystemInfo fs;
      string use_perc_str;

      lineStream >> fs.device >> fs.type >> fs.size >> fs.used >> fs.avail >>
          use_perc_str >> fs.directory;

      // free calculation
      string sizeUnit;
      string noUnitSize;
      string usedUnit;
      string noUnitUsed;

      if (!fs.size.empty()) {
        size_t pos = fs.size.find_last_not_of("0123456789.");
        if (pos != string::npos) {
          sizeUnit = fs.size.substr(pos);
          noUnitSize = fs.size.substr(0, pos);
        }
      }

      if (!fs.used.empty()) {
        size_t pos = fs.used.find_last_not_of("0123456789.");
        if (pos != string::npos) {
          usedUnit = fs.used.substr(pos);
          noUnitUsed = fs.used.substr(0, pos);
        }
      }

      if (noUnitSize.empty()) {
        noUnitSize = "0";
      }
      if (noUnitUsed.empty()) {
        noUnitUsed = "0";
      }

      float sizeF = stof(noUnitSize);
      float usedF = stof(noUnitUsed);

      if (usedUnit.empty()) {
        usedUnit = sizeUnit;
      }

      if (sizeUnit != usedUnit) {
        float freeF = freeDifUnitCalc(sizeF, usedF, sizeUnit, usedUnit);
        fs.free = to_string(freeF).substr(0, to_string(freeF).find('.') + 2) +
                  sizeUnit;
      } else {
        float totFree = sizeF - usedF;
        fs.free =
            to_string(totFree).substr(0, to_string(totFree).find('.') + 2) +
            usedUnit;
      }

      // use_perc float conversion
      if (!use_perc_str.empty() && use_perc_str.back() == '%') {
        use_perc_str.pop_back();
        fs.use_perc = stof(use_perc_str);
      } else {
        fs.use_perc = 0.0f;
      }

      if (!fs.device.empty() && !fs.type.empty() && !fs.directory.empty()) {
        fileSystems.push_back(fs);
      }
    }
  }
  return fileSystems;
}

/*
 * Helper function to return the difference of two storage amounts of different
 * units keeping the unit of the larger (size) value
 */

float freeDifUnitCalc(float size, float used, string sizeUnit,
                      string usedUnit) {
  double trueSize = convertToBase(size, sizeUnit);
  double trueUsed = convertToBase(used, usedUnit);

  if (trueSize < 0 || trueUsed < 0) {
    return size;
  }

  double diff = trueSize - trueUsed;

  diff = diff / pow(1024, sizeUnit[0] == 'k'   ? 1
                          : sizeUnit[0] == 'M' ? 2
                          : sizeUnit[0] == 'G' ? 3
                          : sizeUnit[0] == 'T' ? 4
                                               : 0);
  return diff;
}

/*
 * Helper function to return the size of an item in bytes
 */

double convertToBase(float value, const string& unit) {
  switch (unit[0]) {
    case 'k':
      return value * 1024;
    case 'M':
      return value * pow(1024, 2);
    case 'G':
      return value * pow(1024, 3);
    case 'T':
      return value * pow(1024, 4);
    case 'B':
      return value;
    case '\0':
      return value;
    default:
      cout << value << " " << unit << endl;
      return -1;
  }
}
