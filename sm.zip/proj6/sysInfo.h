#ifndef SYSINFO_H
#define SYSINFO_H

#include <string>
#include <vector>

float diskSpaceInfo();
std::string findCPUModelName();
float memInfo();
std::string getKernelVersion();
std::string getOSReleaseVersion();
std::vector<int> cpu_stats();
std::vector<std::string> GetCPUNames();
int cpu_usage(std::string cpu_name);
int MemoryUsage();
int SwapUsage();
std::vector<int> NetworkUsage();
int NumCPUs();
std::string GetVirtualMemorySize(int pid);
std::string GetResidentMemorySize(int pid);
std::string GetSharedMemorySize(int pid);
std::string GetCPUTime(int pid);
std::string GetProcessStartTime(int pid);
std::string GetProcessUser(int pid);
std::string GetProcessStatus(int pid);
std::string GetCommandLine(int pid);
int GetProcessNiceValue(int pid);
int GetProcessPriority(int pid);
std::string GetProcessSecurityContext(int pid);
std::string GetWaitingChannel(int pid);
std::string GetControlGroup(int pid);
std::string GetWritableMemory(int pid);
std::string GetXServerMem(int pid);

#endif  // SYSINFO_H
