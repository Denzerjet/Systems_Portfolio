// #include "resourcespage.h"

// #include <QtCharts/QCategoryAxis>
// #include <QtCharts/QChart>
// #include <QtCharts/QChartView>
// #include <QtCharts/QLineSeries>
// #include <QTimer>

// ResourcesPage::ResourcesPage(QWidget* parent) : QWidget(parent) {
//     setupUI();
// }

// void ResourcesPage::setupUI() {
//     ui = new Ui::ResourcesPage();
//     ui->setupUi(this);
// }


// void ResourcesPage::SetUpTestGraph() {
//     ui->cpu_graph_widget->setStyleSheet("background-color: red;");

//     QtCharts::QLineSeries *series = new QtCharts::QLineSeries(this);
//     QtCharts::QChart *chart = new QtCharts::QChart();
//     chart->addSeries(series);
//     chart->createDefaultAxes();
//     chart->setTitle("Real-time Data Example");

//     QtCharts::QChartView *chartView = new QtCharts::QChartView(chart, this);
//     chartView->setRenderHint(QPainter::Antialiasing);
//     // 4:3 ratio
//     chartView->resize(400, 300);
//     chart->axisX()->setLabelsVisible(false);
//     static int x = 0;
//     static int maxPoints = 60;
//     chart->axisY()->setRange(0, 100);
//     chart->axisX()->setRange(x - maxPoints, x);
//     chartView->show();

//     QTimer *timer = new QTimer(this);
//     QObject::connect(timer, &QTimer::timeout, this, [series, chart]() {
//         series->append(x, qrand() % 100);
//         x++;

//         chart->axisX()->setRange(x - maxPoints, x);
//         chart->axisY()->setRange(0, 100);

//         chart->update();
//         if (series->count() > maxPoints) {
//             series->remove(0);
//         }
//     });
//     timer->start(1000);



//     // QVBoxLayout *layout = ui->cpu_graph_widget->layout();
//     QLayout *layout = ui->cpu_graph_widget->layout();

//     if (layout == nullptr) {
//         layout = new QVBoxLayout(ui->cpu_graph_widget);
//     }

//     layout->addWidget(chartView);
// } /* SetUpTestGraph() */
