#include "sysInfo.h"

#include <pwd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;

const size_t byte_to_gib = 1024 * 1024 * 1024;
const size_t num_cpu_modes = 10;
const size_t byte_to_kib = 1024;
const size_t date_buff_size = 100;
const size_t utime_ind = 14;
const size_t stime_ind = 15;
const size_t starttime_ticks_ind = 22;

/*
 * Returns the total amount of disk space as a float
 */

float diskSpaceInfo() {
  std::filesystem::space_info system_info = std::filesystem::space("/");
  float total_space = static_cast<float>(system_info.capacity) / (byte_to_gib);
  return total_space;
} /* diskSpaceInfo() */

/*
 * gets the number of cpus on the machine
 */

int NumCPUs() {
  char file_path[] = "/proc/stat";
  std::ifstream file(file_path);
  int num_cpus = 0;

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return num_cpus;
  }

  std::string line;
  std::string cpu = "cpu";

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(cpu) != 0) {
      // If we reach an invalid entry
      break;
    }

    ++num_cpus;
  }

  return num_cpus;
} /* NumCPUs() */

/*
 * gets the usage for each cpu
 */

std::vector<int> cpu_stats() {
  char file_path[] = "/proc/stat";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return std::vector<int>();
  }

  // A 2D vector for all the CPU entries
  std::vector<int> cpu_infos(NumCPUs(), 0);

  std::string line;
  std::string cpu = "cpu";
  int cpu_ind = 0;

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(cpu) != 0) {
      // If we reach an invalid entry
      break;
    }

    int stat_ind = 1;
    long long idle_time = 0;
    long long up_time = 0;

    while (line_stream >> word) {
      // 4 and 5 are idle
      if ((stat_ind == 4) || (stat_ind == 5)) {
        idle_time += stoll(word);
      } else {
        up_time += stoll(word);
      }
      ++stat_ind;
    }

    // calculate usage
    int usage = 0;
    if (idle_time + up_time != 0) {
      usage = (int)(100 * (up_time) / (idle_time + up_time));
    }

    cpu_infos[cpu_ind] = usage;

    ++cpu_ind;
  }

  file.close();
  file = std::ifstream();

  return cpu_infos;
} /* cpu_stats() */

/*
 * gets cpu usage of a specific cpu
 */

int cpu_usage(std::string cpu_name) {
  char file_path[] = "/proc/stat";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return -1;
  }

  std::string line;
  std::string cpu = "cpu";

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(cpu) != 0) {
      // If we reach an invalid entry
      break;
    }

    if (word == cpu_name) {
      // found the right cpu
      int stat_ind = 1;
      long long idle_time = 0;
      long long up_time = 0;

      while (line_stream >> word) {
        // 4 and 5 are idle
        if ((stat_ind == 4) || (stat_ind == 5)) {
          idle_time += stoll(word);
          // printf("idle time: %lld\n",
        } else {
          up_time += stoll(word);
        }
        ++stat_ind;
      }

      // calculate usage
      int usage = -1;
      if (idle_time + up_time != 0) {
        usage = (int)(100 * (up_time) / (idle_time + up_time));
      }

      // ret it
      file.close();
      file = std::ifstream();
      return usage;
    }
  }

  file.close();
  file = std::ifstream();

  return -1;
} /* cpu_usage() */

/*
 * returns an array of all of the cpu names
 */

std::vector<std::string> GetCPUNames() {
  char file_path[] = "/proc/stat";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return std::vector<std::string>();
  }

  int maybe_num_cpus = std::count(std::istreambuf_iterator<char>(file),
                                  std::istreambuf_iterator<char>(), '\n');
  file.close();
  file = std::ifstream();

  // A 2D vector for all the CPU entries
  std::vector<std::string> cpu_names(maybe_num_cpus, "");
  file = std::ifstream(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return std::vector<std::string>();
  }

  std::string line;
  std::string cpu = "cpu";
  int num_cpus = 0;

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(cpu) != 0) {
      // If we reach an invalid entry
      cpu_names[num_cpus] = "INVALID";
      break;
    } else {
      cpu_names[num_cpus] = word;
    }

    ++num_cpus;
  }

  file.close();
  file = std::ifstream();

  return cpu_names;
}

/*
 * Returns the CPU model name as a string
 */

string findCPUModelName() {
  ifstream file("/proc/cpuinfo");
  if (!file.is_open()) {
    cerr << "unable to open file" << endl;
    return "";
  }

  string line;
  string model_name;
  while (getline(file, line)) {
    if (line.find("model name") != string::npos) {
      model_name = line.substr(line.find(":") + 2);
      break;
    }
  }

  file.close();
  return model_name;
} /* findCPUModelName() */

/*
 * Returns the total amount of ram in GiB as a single decimal float
 */

float memInfo() {
  ifstream file("/proc/meminfo");
  if (!file.is_open()) {
    cerr << "unable to open file" << endl;
    return -1;
  }

  string line;
  string total_ram;
  long long ramTotalLong;
  while (getline(file, line)) {
    if (line.find("MemTotal:") != string::npos) {
      total_ram = line.substr(line.find(":") + 1);
      total_ram.erase(0, total_ram.find_first_not_of(" \t\n\r\f\v"));
      total_ram.erase(total_ram.find_last_not_of(" \t\n\r\f\v") + 1);
      size_t pos_of_kB = total_ram.find(" kB");
      if (pos_of_kB != string::npos) {
        total_ram = total_ram.substr(0, pos_of_kB);
      }
      ramTotalLong = stoll(total_ram);
      break;
    }
  }
  file.close();

  return ((float)(ramTotalLong / 100000) / 10);
} /* memInfo() */

/*
 * Returns Kernel version as a string
 */

string getKernelVersion() {
  ifstream versionFile("/proc/version");
  if (!versionFile.is_open()) {
    cerr << "Error: Unable to open /proc/version" << endl;
    return "";
  }
  string line;
  getline(versionFile, line);
  versionFile.close();
  size_t versionStart = line.find("version") + 8;
  size_t versionEnd = line.find(' ', versionStart);
  string kernelVersion = line.substr(versionStart, versionEnd - versionStart);
  return "Kernel Linux " + kernelVersion;
} /* getKernelVersion() */

/*
 * Returns the OS Release Version as a string
 */

string getOSReleaseVersion() {
  ifstream OSReleaseFile("/etc/os-release");
  if (!OSReleaseFile.is_open()) {
    cerr << "Error: Unable to open /etc/os-release" << endl;
    return "";
  }
  string line;
  while (getline(OSReleaseFile, line)) {
    if (line.find("PRETTY_NAME=") == 0) {
      size_t start = line.find("\"") + 1;
      size_t end = line.rfind("\"");
      return line.substr(start, end - start);
    }
  }
  return "OS RELEASE VERSION NOT FOUND";
} /* getOSReleaseVersion() */

/*
 * Gets the memory usage as a percent
 * between 0 and 100
 */

int MemoryUsage() {
  // memfree is available
  // memtotal is... total
  char file_path[] = "/proc/meminfo";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return -1;
  }

  std::string line;
  std::string memtotal_str = "MemTotal";
  std::string memavail_str = "MemAvailable";

  long long mem_total = -1;
  long long mem_avail = -1;

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    if ((mem_total != -1) && (mem_avail != -1)) {
      file.close();
      file = std::ifstream();

      int mem_usage = static_cast<int>(
          100.0 * (1.0 - static_cast<double>(mem_avail) / mem_total));

      return mem_usage;
    }

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(memtotal_str) == 0) {
      line_stream >> word;
      mem_total = stoll(word);
      continue;
    }

    if (word.find(memavail_str) == 0) {
      line_stream >> word;
      mem_avail = stoll(word);
      continue;
    }
  }

  file.close();
  file = std::ifstream();

  return -1;

} /* MemoryUsage() */

/*
 * retrieves the swap usage as an int percentage
 */

int SwapUsage() {
  // memfree is available
  // memtotal is... total
  char file_path[] = "/proc/meminfo";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return -1;
  }

  std::string line;
  std::string memtotal_str = "SwapTotal";
  std::string memavail_str = "SwapFree";

  long long swap_total = -1;
  long long swap_avail = -1;

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    if ((swap_total != -1) && (swap_avail != -1)) {
      file.close();
      file = std::ifstream();

      int swap_usage = static_cast<int>(
          100.0 * (1.0 - static_cast<double>(swap_avail) / swap_total));

      return swap_usage;
    }

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    if (word.find(memtotal_str) == 0) {
      line_stream >> word;
      swap_total = stoll(word);
      continue;
    }

    if (word.find(memavail_str) == 0) {
      line_stream >> word;
      swap_avail = stoll(word);
      continue;
    }
  }

  file.close();
  file = std::ifstream();

  return -1;
} /* swap_usage() */

/*
 * returns the network usage
 * receiving at ind 0, sending at ind 1
 */

std::vector<int> NetworkUsage() {
  // lo is first word
  // receive is first word after
  // send in 9th

  std::vector<int> usage = std::vector<int>(2, -1);

  char file_path[] = "/proc/net/dev";
  std::ifstream file(file_path);

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return usage;
  }

  std::string line;
  std::string network_str = "lo:";

  int line_num = 1;

  // Read each line
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string word;

    if ((line_num == 1) || (line_num == 2)) {
      ++line_num;
      continue;
    }

    // Extract the next whitespace-separated word from the line_stream
    line_stream >> word;

    int ind = 1;
    while (line_stream >> word) {
      if (ind == 1) {
        usage[0] += static_cast<int>(stoll(word) / byte_to_gib);
      } else if (ind == 9) {
        usage[1] += static_cast<int>(stoll(word) / byte_to_gib);
      }
      ++ind;
    }
  }

  file.close();
  file = std::ifstream();
  return usage;
} /* NetworkUsage() */

/*
 * retrieves the virtual memory size of a
 * process in bytes
 */

std::string GetVirtualMemorySize(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/stat";
  std::ifstream file(file_path.c_str());

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return "";
  }

  std::string line;

  // Read each line
  std::getline(file, line);
  std::istringstream line_stream(line);
  std::string word;

  // Extract the next whitespace-separated word from the line_stream

  int ind = 1;
  while (line_stream >> word) {
    if (ind == 23) {
      file.close();
      file = std::ifstream();
      std::string size_str = word + " bytes";
      return size_str;
    }
    ++ind;
  }

  file.close();
  file = std::ifstream();
  return "";
} /* GetVirtualMemorySize() */

/*
 * retrieves the resident memory size
 * in bytes
 */

/*
 * retrieves the resident memory size of a
 * process in bytes
 */

std::string GetResidentMemorySize(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/stat";
  std::ifstream file(file_path.c_str());

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return "";
  }

  std::string line;

  // Read each line
  std::getline(file, line);
  std::istringstream line_stream(line);
  std::string word;

  // Extract the next whitespace-separated word from the line_stream

  int ind = 1;
  while (line_stream >> word) {
    if (ind == 24) {
      break;
    }
    ++ind;
  }

  long long resident_set_size = stoll(word);
  long long page_size = sysconf(_SC_PAGESIZE);

  if (page_size == -1) {
    std::cerr << "Failed to determine page size" << std::endl;
    return "";
  }

  long long total_resident_size = resident_set_size * page_size;

  std::string resident_size_str =
      std::to_string(total_resident_size) + " bytes";

  file.close();
  file = std::ifstream();
  return resident_size_str;
} /* GetResidentMemorySize() */

/*
 * retrieves the shared memory size of a
 * process in bytes
 */

std::string GetSharedMemorySize(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/statm";
  std::ifstream file(file_path.c_str());

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return "";
  }

  std::string line;

  // Read each line
  std::getline(file, line);
  std::istringstream line_stream(line);
  std::string word;

  // Extract the next whitespace-separated word from the line_stream

  int ind = 1;
  while (line_stream >> word) {
    if (ind == 3) {
      break;
    }
    ++ind;
  }

  long long shared_set_size = stoll(word);
  long long page_size = sysconf(_SC_PAGESIZE);

  if (page_size == -1) {
    std::cerr << "Failed to determine page size" << std::endl;
    return "";
  }

  long long total_shared_size = shared_set_size * page_size;

  std::string shared_size_str = std::to_string(total_shared_size) + " bytes";

  file.close();
  file = std::ifstream();
  return shared_size_str;
} /* GetSharedMemorySize() */

/*
 * retrieves the cpu time
 */

std::string GetCPUTime(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/stat";
  std::ifstream file(file_path.c_str());

  if (!file.is_open()) {
    std::cerr << "Error: Unable to open file " << file_path << std::endl;
    return "";
  }

  std::string line;

  // Read each line
  std::getline(file, line);
  std::istringstream line_stream(line);
  std::string word;

  // Extract the next whitespace-separated word from the line_stream

  int ind = 1;
  long utime = 0;
  long stime = 0;
  while (line_stream >> word) {
    if (ind == utime_ind) {
      utime = stoll(word);
    } else if (ind == stime_ind) {
      stime = stoll(word);
    }
    ++ind;
  }

  long long shared_set_size = utime + stime;
  long long clock_tick = sysconf(_SC_CLK_TCK);

  if (clock_tick == -1) {
    std::cerr << "Failed to determine page size" << std::endl;
    return "";
  }

  long long total_cpu_time = shared_set_size / clock_tick;

  std::string cpu_time_str = std::to_string(total_cpu_time) + " seconds";

  file.close();
  file = std::ifstream();
  return cpu_time_str;
} /* GetCPUTime() */

/*
 * gets boot time of a process
 */

std::time_t GetBootTime() {
  std::ifstream proc_stat("/proc/stat");

  if (!proc_stat.is_open()) {
    return -1;
  }

  std::string line;

  while (std::getline(proc_stat, line)) {
    if (line.rfind("btime", 0) == 0) {
      std::time_t boot_time = std::stol(line.substr(6));
      return boot_time;
    }
  }

  return 0;
} /* GetBootTime() */

/*
 * retrieves the process start time
 * in a [day hour:minute am/pm] format
 */

std::string GetProcessStartTime(int pid) {
  std::ifstream proc_stat("/proc/" + std::to_string(pid) + "/stat");

  if (!proc_stat.is_open()) {
    return "Failed to open /proc/[pid]/stat";
  }

  std::string word;
  long long starttime_ticks;

  for (int i = 0; i < starttime_ticks_ind; ++i) {
    proc_stat >> word;
  }

  proc_stat >> starttime_ticks;

  long clock_ticks = sysconf(_SC_CLK_TCK);

  if (clock_ticks == -1) {
    return "Failed to get clock ticks";
  }

  std::time_t boot_time = GetBootTime();
  std::time_t process_start_time = boot_time + starttime_ticks / clock_ticks;

  char buffer[date_buff_size];
  std::tm *local_time = std::localtime(&process_start_time);

  if (!local_time) {
    return "Failed to convert to local time";
  }

  std::strftime(buffer, sizeof(buffer), "%A %I:%M %p", local_time);
  return std::string(buffer);
} /* GetProcessStartTime() */

/*
 * Get the users name
 */

std::string GetProcessUser(int pid) {
  std::string statusFilePath = "/proc/" + std::to_string(pid) + "/status";
  std::ifstream file(statusFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string line;
  while (std::getline(file, line)) {
    if (line.find("Uid:") == 0) {
      std::istringstream ss(line);
      std::string uidLabel, uid;
      ss >> uidLabel >> uid;
      struct passwd *pw = getpwuid(std::stoi(uid));
      return pw ? pw->pw_name : "Unknown";
    }
  }
  return "Unknown";
} /* GetProcessUser() */

/*
 * Get the status of each process
 */

std::string GetProcessStatus(int pid) {
  std::string statusFilePath = "/proc/" + std::to_string(pid) + "/status";
  std::ifstream file(statusFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string line;
  while (std::getline(file, line)) {
    if (line.find("State:") == 0) {
      return line.substr(line.find(":") + 2);
    }
  }
  return "Unknown";
} /* GetProcessStatus() */

/*
 * Get cmd line
 */

std::string GetCommandLine(int pid) {
  std::string cmdFilePath = "/proc/" + std::to_string(pid) + "/cmdline";
  std::ifstream file(cmdFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string cmd;
  std::getline(file, cmd, '\0');
  return cmd.empty() ? "[No Command]" : cmd;
} /* GetCommandLine() */

/*
 * Get the nice value
 */

int GetProcessNiceValue(int pid) {
  std::string statFilePath = "/proc/" + std::to_string(pid) + "/stat";
  std::ifstream file(statFilePath);
  if (!file.is_open()) {
    return -1;
  }
  std::string line;
  std::getline(file, line);
  std::istringstream lineStream(line);
  std::string word;
  int index = 1;
  while (lineStream >> word) {
    if (index == 19) {
      return std::stoi(word);
    }
    ++index;
  }

  return -1;
} /* GetProcessNiceValue() */

/*
 * Get the process priority
 */

int GetProcessPriority(int pid) {
  std::string statFilePath = "/proc/" + std::to_string(pid) + "/stat";
  std::ifstream file(statFilePath);

  if (!file.is_open()) {
    return -1;
  }
  std::string line;
  std::getline(file, line);
  std::istringstream lineStream(line);
  std::string word;
  int index = 1;
  while (lineStream >> word) {
    if (index == 18) {
      return std::stoi(word);
    }
    ++index;
  }

  return -1;
} /* GetProcessPriority() */

/*
 * gets the security context
 */

std::string GetProcessSecurityContext(int pid) {
  std::string attrFilePath = "/proc/" + std::to_string(pid) + "/attr/current";
  std::ifstream file(attrFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string securityContext;
  std::getline(file, securityContext);
  file.close();
  return securityContext.empty() ? "N/A" : securityContext;
} /* GetProcessSecurityContext() */

/*
 * Get the waiting channel
 */

std::string GetWaitingChannel(int pid) {
  std::string statFilePath = "/proc/" + std::to_string(pid) + "/wchan";
  std::ifstream file(statFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string waitingChannel;
  std::getline(file, waitingChannel);
  file.close();
  return waitingChannel.empty() ? "N/A" : waitingChannel;
} /* GetWaitingChannel() */

/*
 * Get the control group
 */

std::string GetControlGroup(int pid) {
  std::string cgroupFilePath = "/proc/" + std::to_string(pid) + "/cgroup";
  std::ifstream file(cgroupFilePath);
  if (!file.is_open()) {
    return "Unknown";
  }
  std::string line;
  std::ostringstream controlGroup;
  while (std::getline(file, line)) {
    controlGroup << line << " ";
  }
  file.close();
  return controlGroup.str().empty() ? "N/A" : controlGroup.str();
} /* GetControlGroup() */

/*
 * Finds amt of memory with w permissions
 */

std::string GetWritableMemory(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/maps";
  std::ifstream file(file_path);
  if (!file.is_open()) {
    return "N/A";
  }
  std::string line;
  long long writable_memory = 0;
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string range;
    std::string permissions;
    std::string offset;
    std::string dev;
    std::string inode;
    std::string path;
    line_stream >> range >> permissions >> offset >> dev >> inode;
    if (permissions.find('w') != std::string::npos) {
      std::string start_addr_str = range.substr(0, range.find('-'));
      std::string end_addr_str = range.substr(range.find('-') + 1);
      long long start_addr = std::stoll(start_addr_str, nullptr, 16);
      long long end_addr = std::stoll(end_addr_str, nullptr, 16);
      writable_memory += (end_addr - start_addr);
    }
  }
  file.close();

  return std::to_string(writable_memory / 1024) + " KiB";
} /* GetWritableMemory() */

std::string GetXServerMem(int pid) {
  std::string pid_str = std::to_string(pid);
  std::string file_path = "/proc/" + pid_str + "/maps";
  std::ifstream file(file_path);
  if (!file.is_open()) {
    return "N/A";
  }
  std::string line;
  long long x_server_memory = 0;
  while (std::getline(file, line)) {
    std::istringstream line_stream(line);
    std::string range, permissions, offset, dev, inode, path;
    line_stream >> range >> permissions >> offset >> dev >> inode;
    std::getline(line_stream, path);
    if (path.find("libX11") != std::string::npos ||
        path.find("libGL") != std::string::npos) {
      std::string start_addr_str = range.substr(0, range.find('-'));
      std::string end_addr_str = range.substr(range.find('-') + 1);
      long long start_addr = std::stoll(start_addr_str, nullptr, 16);
      long long end_addr = std::stoll(end_addr_str, nullptr, 16);
      x_server_memory += (end_addr - start_addr);
    }
  }
  file.close();
  return std::to_string(x_server_memory / 1024) + " KiB";
}

/*
 * example usage of each function printing out the info given

int main() {
  string model_name = findCPUModelName();
  float total_ram = memInfo();
  float total_storage = diskSpaceInfo();
  cout << "CPU Model Name: " << model_name << endl;
  cout << "Total RAM: " << total_ram << " GiB" << endl;
  cout << "Available Disk Space: " << total_storage << " GiB" << endl;
  return 0;
}*/
