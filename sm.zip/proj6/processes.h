#ifndef PROCESSES_H
#define PROCESSES_H

#include <string>
#include <vector>

struct ProcessInfo {
  std::string name;
  std::string status;
  int pid;
  int parentPid;
  double cpuUsage;
  double memoryUsage;
};

std::vector<ProcessInfo> getAllProcesses();
std::vector<ProcessInfo> getActiveProcesses();
std::vector<ProcessInfo> getUserProcesses(uid_t uid);

double getProcessCPUUsage(const std::string &pidStr);

#endif  // PROCESSES_H
